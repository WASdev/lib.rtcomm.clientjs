/**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
'use strict';
(function (root, factory) {
    "use strict";
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define([], factory);
    } else if (typeof exports === 'object') {
        // Node. Does not work with strict CommonJS, but
        // only CommonJS-like enviroments that support module.exports,
        // like Node.
        /* global module: false */
        module.exports = factory();
    } else {
        // Browser globals (root is window)
        root.ibm = root.ibm || {};
        root.ibm.rtcomm= factory();
  }

}(this, function () {
  /** 
   * @module rtcomm
   * @exports RTCommHubProvider
   */

/** 
 * @namespace
 * @memberof module:rtcomm
 * @private
 */
var util = (function() {

  /**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
var Log = function Log() {
    var LOG_LEVEL = {"MESSAGE": 1,// bin '01' Only MESSAGE lines
        "INFO": 2,  // bin '10'   -- Only Info Messages
        "EVENT": 4, // bin '100'  -- Only EVENT lines
        "DEBUG": 7, // bin '111'  -- DEBUG + INFO + EVENT + MESSAGE 
        "TRACE": 15 }; // bin '1111' (includes) all
    var logLevel = 'INFO';
    this.l = function l(value, obj) {
      
      var ll = (obj && obj.getLogLevel ) ? obj.getLogLevel() : logLevel;
        /*jslint bitwise: true */
            return (LOG_LEVEL[ll] & LOG_LEVEL[value]) === LOG_LEVEL[value];
    };
    this.log = function log(msg)  {
      console.log(msg);
    };
    this.setLogLevel = this.s = function(value) {
        if (value in LOG_LEVEL) {
          logLevel = value;
        } else {
          throw new Error(value + 'is not a valid Log level, try: '+JSON.stringify(LOG_LEVEL));
        }
      };
      
    this.getLogLevel = this.g = function(value) {
       return logLevel;
    };
};

// Enables logging for util methods.
// If already defined, use that one?
var logging =  new Log(),
    l = logging.l,

/**
 *  validate a config object against a reference object
 *
 *  @param {object} config A config object to check against reference
 *  @param {object} reference A Reference object to validate config against.
 *
 *  Reference should contain keys w/ appropriate types attached.
 *
 *
 */
validateConfig = function validateConfig(/* object */ config, /* object */ reference) {
  // take 'reference' and ensure all the entries are in it and have same type.
  for (var key in reference) {
    if (config.hasOwnProperty(key)) {
      if (reference[key] !== typeof config[key]) {
        l('INFO') && console.log("Typeof " +key+ " is incorrect. "+ typeof config[key]+"  Should be a " + reference[key]);
        throw new Error("Typeof " +key+ " is incorrect. "+ typeof config[key]+"  Should be a " + reference[key]);
      }
    } else {
     
      throw new Error("Parameter [" + key + "] is missing in config object");
    }
  }
  return true;
},
/**
 *  When given a config object apply config to it(by default):
 *
 *  defined (already set on the object)
 *  not Private (don't start w/ _ )
 *  not CONSTANT (not all caps)
 *
 *  @param {object} config - Configuration to apply
 *  @param {object} obj - Object to apply config to.
 *  @param {boolean} lenient - If true, apply all config to obj, whether exists or not.
 */
applyConfig = function applyConfig(config, obj, lenient ) {
  var configurable = [];
  // What we can configure
  for (var prop in obj) {
    if (obj.hasOwnProperty(prop)){
      if (prop.match(/^_/)) { continue; }
      if (prop.toUpperCase() === prop) {continue; }
      configurable.push(prop);
    }
  }
  for (var key in config) {
    if(config.hasOwnProperty(key) && ((configurable.indexOf(key) !== -1)|| lenient)) {
      // config key can be set, set it...
      obj[key] = config[key];
    } else{
      throw new Error(key + ' is an invalid property for '+ obj );
    }
  }
  return true;
  //console.log(configurable);
},

setConfig = function(config,requiredConfig, possibleConfig) {
  if (config) {
    // validates REQUIRED config upon instantiation.
    if (requiredConfig) {
      validateConfig(config, requiredConfig);
    }
    // handle logLevel passed in...
    if (config.logLevel) {
      //TODO:  Logging is wonky.
      logging.setLogLevel(config.logLevel);
      delete config.logLevel;
    }
    var configObj = possibleConfig?combineObjects(requiredConfig, possibleConfig): requiredConfig; 
    // at this point, everything in configObj are just available parameters and types, null it out.
    for (var key in configObj) {
      if (configObj.hasOwnProperty(key)) {
        configObj[key] = null;
      }
    }
    // Apply 'config' to configObj and return it.
    key = null;
    for (key in config) {
      if(config.hasOwnProperty(key) && configObj.hasOwnProperty(key)) {
        // config key can be set, set it...
        configObj[key] = config[key];
      } else{
        throw new Error(key + ' is an invalid property for '+ JSON.stringify(configObj) );
      }
    }
    
    return configObj;
  } else {
    throw new Error("A minumum config is required: " + JSON.stringify(requiredConfig));
  }
},
combineObjects = function combineObjects(obj1, obj2) {
  var allkeys = [];
  var combinedObj = {};
  // What keys do we have
  for (var prop in obj1) {
    if (obj1.hasOwnProperty(prop)){
      allkeys.push(prop);
    }    
  }
  prop = null;
  for (prop in obj2) {
    if (obj2.hasOwnProperty(prop)){
      allkeys.push(prop);
    }
  }
  allkeys.forEach(function(key) {
    combinedObj[key] = obj1[key]?obj1[key]:obj2[key];
  });
  return combinedObj;
},

Event = function() {
  /** so, no matter what is passed, let's return a:
  * {name:
  *  object: }
  */
  var event = {};
  // options: string --> Message
  //          object --> (is it an Event, cast it...)
  //  string, string (name,message)
  //  string,string,object

  var args = [].slice.call(arguments);
  if (args.length === 0 ) {
    event.name = "message";
    event.object = {};
 } else if (args.length === 1 ) {
    var arg = args[0];
    if (typeof arg === 'string') {
      event.name = 'message';
      event.message = arg;
    } else if (typeof arg === 'object') {
      if (arg.name && arg.message) {
        event = arg;

      } else {
        console.error("Invalid Object to create Event(must have name/message): ", arg);
      }

    } else {
      console.error("Invalid args to create Event(must have name/message): ", arg);
    }
  } else if (args.length === 2) {
    event.name = args[0];
    event.message = args[1];
  } else if (args.length === 3){
    event.name = args[0];
    event.message = args[1];
    event.object = args[2];
  } else {
    console.error("Too many arguments passed: ", args);
  }
  return event;
},

whenTrue = function(func1, callback, timeout) {
  l('DEBUG') && console.log('whenTrue!', func1, callback, timeout);
  var max = timeout || 500;
  var waittime = 0;
  var min=50;
  
  function test() {
    l('DEBUG') && console.log('whenTrue -- waiting: '+waittime);
    if (waittime > max) {
      callback(false);
      return false;
    }
    var a = func1();
    if (a) {
      l('DEBUG') && console.log('whenTrue TRUE', a);
      callback(a);
      return true;
    } else {
      setTimeout(test,min);
    }
    waittime = waittime+min;
  }
  test();
};


var generateUUID = function() {
    /*jslint bitwise: true */
    var d = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random()*16)%16 | 0;
        d = Math.floor(d/16);
        return (c==='x' ? r : (r&0x7|0x8)).toString(16);
    });
    return uuid;
};


/**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
/** Base Rtcomm class that provides event functionality 
 * @class
 * @memberof module:rtcomm.util
 */
var RtcommBaseObject = {
    /** @lends module:rtcomm.util.RtcommBaseObject.prototype */
    /*
     * Properties

    objName : 'Base',
    id : 'unknown',
    config: {},
    dependencies: {},
    ready: false,
    state: 'unknown',
    states: {},
    events: {},  
     */
    /*
     * Methods
     */
    setState : function(value) {
      if (this.states.hasOwnProperty(value)) {
        this.state = value;
        this.emit(value);
      }
    },
    listEvents : function() {

      console.log('******* ' + this+' Configured events ***********');
      /*jslint forin: true */
      for(var event in this.events) {
          if (this.events.hasOwnProperty(event)) {
            console.log('******* ['+event+'] has '+this.events[event].length+' listeners registered');
          } 
          
        }
    },  
    createEvent: function(event) {
      if (this.hasOwnProperty('events')){
        this.events[event] = []; 
      } else {
        throw new Error('createEvent() requires an events property to store the events');
      }
    },  
    removeEvent: function(event) {
      if (event in this.events) {
        delete this.events[event];
      }   
    },  
    /** Establish a listener for an event */
    on : function(event,callback) {
      //console.log('on -- this.events is: '+ JSON.stringify(this.events));
      // This function requires an events object on whatever object is attached to. and event needs to be defined there.
      if (this.events && this.events[event] && Array.isArray(this.events[event])) {
        l('EVENT', this) && console.log(this+' Adding a listener callback for event['+event+']');
        l('TRACE', this) && console.log(this+' Callback for event['+event+'] is', callback);
        this.events[event].push(callback);
      } else {
        throw new Error("on() requires an events property listing the events. this.events["+event+"] = [];");
      }   
    },  
    /** emit an event from the object */
    emit : function(event, object) {
      if (this.events && this.events[event]) {
        l('EVENT', this) && console.log(this+".emit()  for event["+event+"]", object);
        // Event exists, call all callbacks
        this.events[event].forEach(function(callback) {
          if (typeof callback === 'function') {
            callback(object);
          } else {
            l('EVENT', this) && console.log(this+' Emitting, but no callback for event['+event+']');
          }   
        }); 
      } else {
        throw new Error('emit() requires an events property listing the events. this.events['+event+'] = [];');
      }   
    },
    extend: function(props) {
      var prop, obj;
      obj = Object.create(this);
      for (prop in props) {
        if (props.hasOwnProperty(prop)) {
          obj[prop] = props[prop];
        }
      }
      return obj;
    },
    toString: function() {
      return this.objName + '['+this.id+']';
    }
};

/**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
var RtcommEvent = function RtcommEvent() {
  this.name = "";
  this.message = "";
  this.object = "";
};


  return { Log: Log, RtcommBaseObject:RtcommBaseObject, validateConfig: validateConfig, setConfig: setConfig, applyConfig: applyConfig, generateUUID: generateUUID, whenTrue:whenTrue };
  
})();


/** 
 * @namespace
 * @memberof module:rtcomm
 * @private
 */
var connection = (function() {

  /**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
// rtcservice & util should be defined here:
/*global util:false*/
var logging = new util.Log(),
    setLogLevel = logging.s,
    getLogLevel = logging.g,
    l = logging.l,
    generateUUID = util.generateUUID,    
    validateConfig = util.validateConfig,
    applyConfig = util.applyConfig,
    setConfig = util.setConfig,
    /*global log: false */
    log = function log() {
          // I want to log CallingObject[id].method Message [possibly an object]

          var object = {},
              method = '<none>',
              message = null,
              remainder = null,
              logMessage = "";

          var args = [].slice.call(arguments);

          if (args.length === 0 ) {
            return;
          } else if (args.length === 1 ) {
            // Just a Message, log it...
            message = args[0];
          } else if (args.length === 2) {
            object = args[0];
            message = args[1];
          } else if (args.length === 3 ) {
            object = args[0];
            method = args[1];
            message = args[2];
          } else {
            object = args.shift();
            method = args.shift();
            message = args.shift();
            remainder = args;
          }

          if (object) {
            logMessage = object.toString() + "." + method + ' ' + message;
          } else {
            logMessage = "<none>" + "." + method + ' ' + message;
          }
          // Ignore Colors...
          if (object && object.color) {object.color = null;}
          
          var css = "";
          if (object && object.color) {
            logMessage = '%c ' + logMessage;
            css = 'color: ' + object.color;
            if (remainder) {
              console.log(logMessage, css, remainder);
            } else {
              console.log(logMessage,css);
            }
          } else {
            if (remainder) {
              console.log(logMessage, remainder);
            } else {
              console.log(logMessage);
            }
          }
        }; // end of log/ 
        
    
        
    
/**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
/**

 * @memberof module:rtcomm.connector
 *
 * @classdesc
 * The EndpointConnection encapsulates the functionality to connect and create Sessions.
 * 
 * @param {object}  config   - Config object 
 * @param {string}  config.server -  MQ Server for mqtt.
 * @param {integer} [config.port=1883] -  Server Port
 * @param {string}  config.userid -  Unique user id representing user
 * @param {string}  config.connectorTopicName - Default topic to register with ibmrtc Server
 * @param {string}  [config.connectorTopicPath]
 *  @param {object}  [config.credentials] - Optional Credentials for mqtt server.
 *
 *
 * Events 
 * @event message    Emit a message (MessageFactor.SigMessage)
 * @event newsession  Called when an inbound new session is created, passes the new session.
 * @param {function} config.on  - Called when an inbound message needs
 *    'message' --> ['fromEndpointID': 'string', content: 'string']
 * 
 * @throws  {String} Throws new Error Exception if invalid arguments
 * 
 * @private
 */

var EndpointConnection = function(config) {
  /*
   * Registery Object 
   */
  function Registry(timer) {
    timer = timer || false;
    var registry = {};
    var defaultTimeout = 5000;

    var add = function(item) {

      l('TRACE') && console.log('Registry.add() Adding item to registry: ', item);
      item.on('finished', function() {
        this.remove(item);
      }.bind(this));

      registry[item.id] = item;
      // Set a timeout for transaction
      if (timer) {
        setTimeout(function() {
          if ( item.id in registry ) {
            // didn't execute yet
            var errorMsg = 'Registry timed out ['+item.id+']';
            if (typeof registry[item.id].onFailure === 'function' ) {
              l('DEBUG') && console.log(errorMsg);
              registry[item.id].onFailure({'failureReason': errorMsg});
            } else {
              l('DEBUG') && console.log(errorMsg);
            }
            delete registry[item.id];
          }
        },
        item.timeout || defaultTimeout);
      }
    };

    return {
      add: add,
      remove: function(item) {
        if (item.id in registry) {
          l('DEBUG') && console.log('Removing item from registry: ', item);
          delete registry[item.id];
        } 
      },
      list: function() {
        return Object.keys(registry);
      },
      find: function(id) {
        return registry[id] || null ;
      }
    };
  } // End of Registry definition

  /*
   * create an RtcommService for use by the EndpointConnection
   */ 
  var createRtcommService = function(config) {
    var rtcService = new RtcommService(config);
    return rtcService; 
  };
  /*
   * Process a message, expects a bind(this) attached.
   */
  var processMessage = function(message) {
    var content = message.content;
    var fromEndpointID = message.fromEndpointID;
    var rtcommMessage = MessageFactory.cast(content);
    l('DEBUG') && console.log(this+'.processMessage() processing Message', rtcommMessage);
    if (rtcommMessage.transID) {
      // this is in context of a transaction.
      if (rtcommMessage.method === 'RESPONSE') {
        // close an existing transaction we started.
        l('TRACE') && console.log(this+'.processMessage() this is a RESPONSE', rtcommMessage);
        var transaction = this.transactions.find(rtcommMessage.transID);
        if (transaction) {
          l('TRACE') && console.log(this+'.processMessage() existing transaction: ', transaction);
          transaction.finish(rtcommMessage);
        } else { 
          console.error('Transaction ID: ['+rtcommMessage.transID+'] not found, nothing to do with RESPONSE:',rtcommMessage);
        }
      } else if (rtcommMessage.method === 'START_SESSION' )  {
        this.emit('newsession', this.createSession({message:rtcommMessage, fromEndpointID: fromEndpointID}));
      } else {
        // We have a transID, we need to pass message to it.
        // May fail? check.
        this.transactions.find(rtcommMessage.transID).emit('message',rtcommMessage);
      }
    } else if (rtcommMessage.sigSessID) {
      // has a session ID, fire it to that.
      this.emit(rtcommMessage.sigSessID, rtcommMessage);
    } else {
      this.emit('message', rtcommMessage);
    }
  };

  /*
   * Instance Properties
   */
  this.objName = 'EndpointConnection';
//Define events we support
  this.events = {
      'message': [],
      'newsession': []};
  this.registered = false;
//Define configuration
  this.config = {
  };
  this.ready = false;
  this._init = false;
  this.id = config.userid;

//Registry Store for Session & Transactions
  this.sessions = new Registry();
  this.transactions = new Registry(true);

//create our Service
  this.rtcService = createRtcommService(config);
  this.rtcService.on('message', processMessage.bind(this));
//Define configuration
  this.config = {
      userid  : config.userid,
      myTopic : this.rtcService.config.myTopic
  };
  this._init = true;
};

EndpointConnection.prototype = util.RtcommBaseObject.extend (
    (function() {
      /*
       * Class Globals
       */
      var registerTimer = null;

      /** @lends module:rtcomm.connector.EndpointConnection.prototype */
      return {
        /*
         * Instance Methods
         */


        setLogLevel: setLogLevel,
        getLogLevel: getLogLevel,
        /* Factory Methods */
        /**
         * Create a message for this EndpointConnection
         */
        createMessage: function(type) {
          if (!this.ready) {
            throw new Error('not Ready -- call connect() first');
          }
          var message = MessageFactory.createMessage(type);
          if (message.hasOwnProperty('fromTopic')) {
            message.fromTopic = this.config.myTopic;
          }
          l('DEBUG')&&console.log(this+'.createMessage() returned', message);
          return message;
        },
        /**
         * Create a Response Message for this EndpointConnection
         */
        createResponse : function(type) {
          if (!this.ready) {
            throw new Error('not Ready -- call connect() first');
          }
          var message = MessageFactory.createResponse(type);
          return message;
        },
        /**
         * Create a Transaction
         */
        createTransaction : function(options,onSuccess,onFailure) {
          if (!this.ready) {
            throw new Error('not Ready -- call connect() first');
          }
          // options = {message: message, timeout:timeout}
          var t = new Transaction(options, onSuccess,onFailure);
          t.endpointconnector = this;
          l('DEBUG') && console.log(this+'.createTransaction() Transaction created: ', t);
          this.transactions.add(t);
          return t;
        },
        /**
         * Create a Session
         */
        createSession : function createSession(config) {
          if (!this.ready) {
            throw new Error('not Ready -- call connect() first');
          }
          // start a transaction of type START_SESSION
          // createSession({message:rtcommMessage, fromEndpointID: fromEndpointID}));
          // if message & fromEndpointID -- we are inbound..
          var session = new SigSession(config);
          session.endpointconnector = this;
          // apply EndpointConnection
          this.createEvent(session.id);
          this.on(session.id,session.processMessage.bind(session));
          this.sessions.add(session);
          return session;
        },
        /**
         * common query fucntionality
         * @private 
         * 
         */
        _query : function(message, contentfield, cbSuccess, cbFailure) {
          var successContent = contentfield || 'peerContent';
          var onSuccess = function(query_response) {
            if (cbSuccess && typeof cbSuccess === 'function') {
              if (query_response) {
                var successMessage = query_response[successContent] || null;
                cbSuccess(successMessage);
              } 
            } else {
              l('DEBUG') && console.log('query returned: ', query_response);
            }
          };
          var onFailure = function(query_response) {
            if (cbFailure && typeof cbFailure === 'function') {
              if (query_response && query_response.failureReason) {
                cbFailure(query_response.failureReason);
              }
            } else {
              console.error('query failed:', query_response);
            }
          };
          if (this.ready) {
            var t = this.createTransaction({message: message}, onSuccess,onFailure);
            t.start();
          } else {
            console.error(this+'._query(): not Ready!');
          }
        },
        /**
         * connect the EndpointConnection to the server endpointConnection
         * 
         * @param {callback} [cbSuccess] Optional callbacks to confirm success/failure
         * @param {callback} [cbFailure] Optional callbacks to confirm success/failure
         */
        connect : function(cbSuccess, cbFailure) {
          if (!this._init) {
            throw new Error('not initialized -- call init() first');
          }
          if (this.ready) {
            throw new Error(this+".connect() is already connected!");
          }
          var onSuccess = function(service) {
            this.ready = true;
            l('DEBUG') && console.log('EndpointConnection.connect() Success, calling callback - service:', service);
            if (cbSuccess && typeof cbSuccess === 'function') {
              cbSuccess(service);
            } else {
              console.log('No callback, but connect was successful');
            }
          };
          var onFailure = function() {
            this.ready = false;
            if (cbFailure && typeof cbFailure === 'function') {
              cbFailure;
              console.log('No callback, connect failed');
            }
          };

          this.rtcService.connect(onSuccess.bind(this),onFailure.bind(this));
        },
        disconnect : function() {
          l('DEBUG') && console.log('EndpointConnection.disconnect() called: ', this.rtcService);
          if (this.registered) {
            this.unregister();
            this.registered = false;
          }
          this.rtcService.destroy();
          l('DEBUG') && console.log('destroyed rtcService');
          this.rtcService = null;
          this.ready = false;
        },
        /** 
         *  Register the 'userid' used in {@link module:rtcomm.RtcommEndpointProvider#init|init} with the
         *  rtcomm service so it can receive inbound requests.
         *
         *  @param {function} [onSuccess] Called when register completes successfully with the returned message about the userid                          
         *  @param {function} [onFailure] Callback executed if register fails, argument contains reason.
         */
        register : function(appContext, cbSuccess, cbFailure) {
          /*
           * create a register message
           * send it.
           * onSuccess is called when a Response is received
           * onFailure if a timeout or if send fails.
           * TODO:  Change this when we start using LWT  
           * 
           */
          l('DEBUG') && console.log('Register Called! with this: ', this);
          l('DEBUG') && console.log('Register Called! args ', arguments);
          var minimumReregister = 30;  // 30 seconds;
          var onSuccess = function(register_message) {

            l('DEBUG') && console.log(this+'register() REGISTER RESPONSE: ', register_message);
            if (register_message.orig === 'REGISTER' && register_message.expires) {
              var expires = register_message.expires;
              l('DEBUG') && console.log(this+'.register() Message Expires in: '+ expires);
              /* We will reregister every expires/2 unless that is less than minimumReregister */
              var regAgain = expires/2>minimumReregister?expires/2:minimumReregister;
              // we have a expire in seconds, register a timer...
              l('DEBUG') && console.log(this+'.register() Setting Timeout to:  '+regAgain*1000);
              registerTimer = setTimeout(this.register.bind(this,appContext), regAgain*1000);
            }
            this.registered = true;
            // Call our passed in w/ no info... 
            if (cbSuccess && typeof cbSuccess === 'function') {
              cbSuccess();
            } else {
              l('DEBUG') && console.log(this + ".register() Register Succeeded (use onSuccess Callback to get the message)", message);
            }
          };
          // {'failureReason': 'some reason' }
          var onFailure = function(errorObject) {
            if (cbFailure && typeof cbFailure === 'function') {
              cbFailure(errorObject.failureReason);
            } else {
              console.error('Registration failed : '+errorObject.failureReason);
            }
          };
          // Call register!
          if (this.ready) {
            var message = this.createMessage('REGISTER');
            message.appContext = appContext || "none";
            message.regTopic = message.fromTopic;
            var t = this.createTransaction({message:message}, onSuccess.bind(this), onFailure.bind(this));
            t.start();
          } else {
            if (cbSuccess && typeof cbSuccess === 'function') {
              cbFailure('Not Ready, unable to register.');
            } else {
              console.error('Not Ready, unable to register.');
            }
          }
        },
        /** 
         *  Unregister the userid associated with the EndpointConnection  
         */
        unregister : function() {

          if (registerTimer) {
            console.log('Timer is:'+registerTimer);
            clearTimeout(registerTimer);
            registerTimer=null;
            var message = this.createMessage('REGISTER');
            message.regTopic = message.fromTopic;
            message.expires = "0";
            this.send({'message':message});
            this.registered = false;
          } else {
            l('DEBUG') && console.log(this+' No registration found, cannot unregister');
          }
        },
        /**
         * Service Query for supported services by endpointConnection
         */
        service_query: function(cbSuccess, cbFailure) {
          if (this.ready) {
            var message = this.createMessage('SERVICE_QUERY');
            this._query(message, 'services',cbSuccess,cbFailure);
          } else {
            console.error('not ready');
          }
        },

        destroy : function() {
          if (this.ready) {
            this.disconnect();
          }
        },
        /**
         * Send a message
         * 
         */
        send : function(config) {
          if (!this.ready) {
            throw new Error('not Ready -- call connect() first');
          }

          if (config) { 
            this.rtcService.send({message:config.message, toTopic:config.toTopic});
          } else {
            console.error('EndpointConnection.send() Nothing to send');
          }
        }
      };
    })()
);
/**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
/** @class
 * @memberof module:rtcomm.webrtc
 * @private
 */
/* Constructor */

var MessageFactory = (function (){
  // base Template used for everything.
  var _baseHeaders = {
      'rtcommVer': 'v0.0.1',
       'method' : null,
       'fromTopic': null
  };
  
  var _optionalHeaders = {
      'sigSessID':null,
      'transID':null,
      'reason': null,
      'toEndpointID': null,
      'appContext': null
  };
  
  // Override base headers and add new headers for the OUTBOUND message
  // If it is a transaction, it will have a transID
  
  var _messageTemplates = {
      'SERVICE_QUERY' : {
        'method': 'SERVICE_QUERY',
        'transID': null,
      },
      'START_SESSION' : {
        'method': 'START_SESSION',
        'sigSessID':null,
        'transID':null,
        'toEndpointID': null,
        'peerContent': null,
      },
     'STOP_SESSION' : {
        'method': 'STOP_SESSION',
        'sigSessID':null,
        'peerContent': null,
      },
      'PRANSWER': {
        'method': 'PRANSWER',
        'peerContent': null
      },
      // Message is generic and could be anything... 
      'MESSAGE':{
        'method':'MESSAGE',
        'peerContent': null
      },
      'ICE_CANDIDATE':{
        'method':'ICE_CANDIDATE',
        'fromTopic': null
      },
      'REGISTER': {
        'method': 'REGISTER',
        'regTopic':null,
        'appContext':null
      }
  };
  
  var _baseResponseTemplate = {
      'RESPONSE' : {
        'method': 'RESPONSE',
        'orig': null,
        'transID': null,
        'result': null,
      }
  };
  
  var _responseTemplates = {
      'SERVICE_QUERY' : {
        'orig': 'SERVICE_QUERY',
        'services':null
      },
      'START_SESSION' : {
        'orig': 'START_SESSION',
        'sigSessID': null,
        'result': null,
        'peerContent': null,
        'transID': null,
      },
      'REGISTER': {
        'orig': 'REGISTER',
        'expires': 120,
        'result': null,
        'transID': null,
      }
      
  };
  
  function getMessageTemplate(type) {
    var template = {};
    
    objMerge(template,_baseHeaders);
   
    if (_messageTemplates.hasOwnProperty(type)) {
      objMerge(template,_messageTemplates[type]);
      return template;
    } else {
      console.error('Message Type: '+type+' Not found!');
      return null;
    }
  }
  
  function getResponseTemplate(type) {
    var template = {};
    objMerge(template,_baseHeaders);
    objMerge(template, _baseResponseTemplate.RESPONSE);
    if (_responseTemplates.hasOwnProperty(type)) {
      objMerge(template,_responseTemplates[type]);
      return template;
    } else {
      console.error('Message Type: '+type+' Not found!');
      return null;
    }
  }
  
  function objMerge(obj1,obj2) {
    // Take Right Object and place on top of left object.  
    for (var key in obj2) {
      if (obj2.hasOwnProperty(key)) {
        obj1[key] = obj2[key];
      }
    }
  }
  
  var SigMessage = function SigMessage(template) {
    if (template) {
      for (var key in template) {
        if (template.hasOwnProperty(key)) {
          this[key] = template[key];
        }
      }
    }
  };

  SigMessage.prototype = {
      /** Convert message to a specific JSON object 
       * 
       * @returns {JSON} 
       * 
       */
      toJSON: function() {
        var obj = {};
        for (var key in this) {
          if (this.hasOwnProperty(key)) {
            obj[key] = this[key];
          }
        }
        return obj;
      }, 
      /* Override */
      toString: function() {
        // When converted to a string, we return a SPECIFIC object content that matches the Message Template 
        return JSON.stringify(this.toJSON());
      }
  };
  
  function createResponse(type) {
    var message = null;
    var template = getResponseTemplate(type);
    if (template) {
      message = new SigMessage(template);
    } else {
      throw new TypeError('Invalid Message type:'+type+', should be one of: '+ Object.keys(_messageTemplates));
    }
    return message;
  }
  
  function createMessage(type) {
    type = type || 'MESSAGE';
    var message = null;
    var template = getMessageTemplate(type);
    if (template) {
      message = new SigMessage(template);
    } else {
      throw new TypeError('Invalid Message type:'+type+', should be one of: '+ Object.keys(_messageTemplates));
    }
    return message;
  }
  
  function isValid(message) {
    try {
      var tmpmsg = cast(message);
    } catch(e) {
      // unable to cast, not a good message.
      return false;
    }
    return true;
  }
  
  function cast(obj) {
    l('TRACE') && console.log('MessageFactory.cast() Attempting to cast message: ', obj);
  
    if ( typeof obj === 'string') {
      l('TRACE') && console.log('MessageFactory.cast() It is a string... ', obj);
      /* if its a 'STRING' then convert to a object */
      obj = JSON.parse(obj);
      l('TRACE') && console.log('MessageFactory.cast() After JSON.parse... ', obj);
    }
    var template = null;
    if (obj.method) {
      template = (obj.method === 'RESPONSE') ? getResponseTemplate(obj.orig):getMessageTemplate(obj.method);
    } else {
      throw new TypeError('Unable to cast object as a SigMessage');
    }
    var castedMessage = new SigMessage(template);
    for (var prop in obj){
      // console.log("key:" + prop + " = " + obj[prop]);
      if (template.hasOwnProperty(prop) || _optionalHeaders.hasOwnProperty(prop)){
        //    console.log("key:" + prop + " = " + obj[prop]);
        castedMessage[prop] = obj[prop];
      } else {
        l('DEBUG') && console.log('MessageFactory.cast() dropped header: '+prop);
      }
    }  
    l('TRACE') && console.log('MessageFactory.cast() returning casted message:', castedMessage);
    return castedMessage;
  }

  return {
    createMessage:  createMessage,
    createResponse: createResponse,
    cast : cast
  };
})();


/**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
/**
 * @class 
 * @memberof module:rtcomm.connector
 * @classdesc
 *
 * Low level service used to create the RtcommService which connects
 * via mqtt over WebSockets to a server passed via the config object.
 *
 * @param {object}  config   - Config object for RtcService
 * @param {string}  config.server -  MQ Server for mqtt.
 * @param {integer} [config.port=1883] -  Server Port
 * @param {string}  config.userid -  Unique user id representing user
 * @param {string}  config.connectorTopicName - Default topic to register with ibmrtc Server
 * @param {string}  [config.myTopic] - Optional myTopic, defaults to a hash from userid
 * @param {object}  [config.credentials] - Optional Credentials for mqtt server.
 *
 * @param {function} config.on  - Called when an inbound message needs
 *    'message' --> {'fromEndpointID': 'string', content: 'string'}
 * 
 * @throws {string} - Throws new Error Exception if invalid arguments.
 * 
 * @private
 */
var RtcommService = function RtcommService(config) {
  /* Class Globals */

  /*
   * generateClientID - Generates a random 23 byte String for clientID if not passed.
   * The main idea here is that for mqtt, our ID can only be 23 characters and contain
   * certain characters only.
   */

  var generateClientID = function(userid) {
    var validChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var stringLength = 23;
    var clientID = "";
    // otherwise, generate completely randomly.
    for (var j = stringLength-1; j>0 ; --j) {
      clientID += validChars[Math.floor(Math.random()*(validChars.length - 1))];
    }
    return clientID;
  };
  /* 
   * Create an MQTT Client 
   */
  var createMqttClient = function(config) {
    /* global Paho: false */
    /* global Paho.MQTT: false */
    var mqtt = null;
    if (typeof Paho.MQTT === 'object') {
      l('DEBUG') && console.log('RtcService createMqttClient using config: ', config);
      mqtt = new Paho.MQTT.Client(config.server,config.port,config.clientID);
      /* if a connection is lost, this callback is called, reconnect */
      mqtt.onConnectionLost = function(error) {
        if (error.errorCode !== 0) { // 0 means it was on purpose.
          console.error("RtcService: Connection Lost... : ", error  );
        }
      };

    } else {
      throw new Error("RtcommService depends on 'Paho.MQTT' being loaded via mqttws31.js.");
    }
    return mqtt;
  };

  // Our required properties
  this.objName = 'RtcService';
  this.dependencies = {};
  this.config = {};
  this.ready = false;
  this._init = false;
  this.id = null;
  // Events we can emit go here.
  this.events = {'message':[]};

  //config items that are required and must be the correct type or an error will be thrown
  var requiredConfig = { server: 'string', port: 'number', userid: 'string', connectorTopicName: 'string', connectorTopicPath: 'string'};
  var possibleConfig = { credentials : 'object', myTopic: 'string'};

  // the configuration for RtcService
  if (config) {
    this.config = setConfig(config,requiredConfig,possibleConfig);
  } else {
    throw new Error("RtcService instantiation requires a minimum configuration: "+ JSON.stringify(requiredConfig));
  }
  // Populate this.config
  this.config.clientID = this.config.myTopic || generateClientID();
  this.config.myTopic = this.config.myTopic || this.config.connectorTopicPath + this.config.clientID;
  this.config.destinationTopic = this.config.connectorTopicPath + this.config.connectorTopicName;
  // Save an 'ID' for this service.
  this.id = this.config.clientID;
  this.ready = false;
  // Create our MQTT Client.
  var mqttClient = this.dependencies.mqttClient = createMqttClient(this.config);

  mqttClient.onMessageArrived = function (message) {
    l('TRACE') && console.log('MQTT Raw message, ', message);
    var m = /\S+\/(.+)/g.exec(message.destinationName);
    /* rtcommMessage we emit */
    var rtcommMessage = {
        fromEndpointID : m?m[1]:null,
            content: message.payloadString
    };  
    try {
      l('MESSAGE') && console.log(this+' Received message: '+JSON.stringify(rtcommMessage));
      this.emit('message',rtcommMessage);
    } catch(e) {
      console.error('onMessageArrived callback chain failure:',e);
    }
  }.bind(this);
  // Init has be executed.

  this._init = true;

};

/* global util: false */
RtcommService.prototype  = util.RtcommBaseObject.extend(
    /** @lends module:rtcomm.connector.RtcommService.prototype */
    {
      setLogLevel: setLogLevel,
      getLogLevel: getLogLevel,
      /**
       * connect()
       */
      connect: function connect(cbOnsuccess, cbOnfailure) {
        if (!this._init) {
          throw new Error('init() must be called before calling connect()');
        }

        var mqttClient = this.dependencies.mqttClient;
        var mqttConnectOptions = {};

        var onSuccess = cbOnsuccess || function() {
          l('DEBUG')&& console.log(this+'.connect() was successful, override for more information');
        }.bind(this);

        var onFailure = cbOnfailure || function(error) {
          l('DEBUG')&& console.log(this+'.connect() failed, override for more information', error);
        }.bind(this);

        /*
         * onSuccess Callback for mqttClient.connect
         */
        mqttConnectOptions.onSuccess = function() {
          l('DEBUG') && console.log(this + 'mqtt.onSuccess called', mqttClient);
          // Subscribe to all things on our topic.
          // This is may be where we need the WILL stuff
          l('DEBUG') && console.log(this + 'subscribing to: '+ this.config.myTopic+"/#");
          try {
            mqttClient.subscribe(this.config.myTopic+"/#");
          } catch(e) {
            // TODO:  THis failed... Do something with it differently.
            console.error('mqttConnectOptions.onSuccess Subscribe failed: ', e);
            return;
          }
          this.ready = true;
          if (onSuccess && typeof onSuccess === 'function') {
            try {
              onSuccess(this);
            } catch(e) {
              console.error('connect onSuccess Chain Failure... ', e);
            }
          } else {
            console.log("No onSuccess callback... ", onSuccess);
          }
        }.bind(this);

        mqttConnectOptions.onFailure = function(response) {
          l('DEBUG') && console.log(this+'.onFailure: RtcService.connect.onFailure - Connection Failed... ', response);
          if (typeof onFailure === 'function') {
            // When shutting down, this might get called, catch any failures. if we were ready
            // this is unexpected.
            try {
              if (this.ready) { onFailure(response) ;}
            } catch(e) {
              console.error(e);
            }
          } else {
            console.error(response);
          }
        }.bind(this);

        mqttClient.connect(mqttConnectOptions);
      },
      /**
       *  Send a Message
       *
       *  @param {object} message -  RtcMessage to send.
       *  @param {string} [toTopic]  - Topic to send to.  Testing Only.
       *  @param {function} onSuccess
       *  @param {function} onFailure
       *
       */
      send : function(/*object */ config ) {
        if (!this.ready) {
          throw new Error('connect() must be called before calling init()');
        }
        var message = config.message,
        toTopic  = config.toTopic || this.config.destinationTopic,
        // onSuccess Callback
        onSuccess = config.onSuccess || function() {
          l('DEBUG')&& console.log(this+'.send was successful, override for more information');
        }.bind(this),
        // onFailure callback.
        onFailure = config.onFailure|| function(error) {
          l('DEBUG')&& console.log(this+'.send failed, override for more information', error);
        }.bind(this),
        messageToSend = "",
        mqttClient = this.dependencies.mqttClient;

        if (message && typeof message === 'object') {
          // Convert message for mqtt send
          messageToSend = new Paho.MQTT.Message(JSON.stringify(message.toJSON()));
        } else if (typeof message === 'string' ) {
          // If its just a string, we support sending it still, though no practical purpose for htis.
          messageToSend = new Paho.MQTT.Message(message);
        } else {
          console.error('RtcService.send: invalid message', message);
        }
        /*
         * The messaging standard is such that we will send to a topic
         * by appending our clientID as follows:  topic/<clientid>
         *
         * This can be Overridden by passing a qualified topic in as
         * toTopic, in that case we will leave it alone.
         *
         */

        // our topic should contain the topicPath -- we MUST stay in the topic Path... and we MUST append our ID after it, so...
        if (toTopic) {
          l('TRACE') && console.log(this+'.send toTopic is: '+toTopic);
          var begin = this.config.connectorTopicPath;
          var end = this.config.userid;
          var p = new RegExp("^" + begin,"g");
          toTopic = p.test(toTopic)? toTopic : begin + toTopic;
          var p2 = new RegExp(end + "$", "g");
          toTopic = p2.test(toTopic) ? toTopic: toTopic + "/" + this.config.userid;
        } 

        l('TRACE') && console.log(this+'.send using toTopic: '+toTopic);
        if (messageToSend) {
          // Append the 'userid'  We send to /service/userid
          messageToSend.destinationName = toTopic;
          util.whenTrue(
              /* test */ function(){
                return this.ready;
              }.bind(this),
              /* whenTrue */ function(success) {
                if (success) {
                  l('MESSAGE') && console.log(this+'.send() Sent message['+toTopic+']:',message);
                  mqttClient.send(messageToSend);
                  if (typeof onSuccess === 'function' ) {
                    try {
                      onSuccess(null);
                    } catch(e) {
                      console.error('An error was thrown in the onSuccess callback chain', e);
                    }
                  }
                } else {
                  console.error('RtcService.send() failed - Timeout waiting for connect()');
                }
              }.bind(this), 1000);
        } else {
          l('DEBUG') && console.log(this+".send(): Nothing to send");
        }
      },
      /* cleanup */
      destroy: function() {
        this.ready = false;
        //Testin, disconnect can hang for some reason. Commenting out.
        this.dependencies.mqttClient = null;
        // this.dependencies.mqttClient.disconnect();
        l('DEBUG') && console.log(this+'.destroy() called and finished');
      }
    }); // end of Return


/**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 

/** 
 * A SigSession is an end to end signaling session w/ another Peer.
 * 
 * <p>
 * It is part of a WebRTCConnection and should ONLY be used via a WebRTCConnection.  It 
 * should only be created by 'EndpointConnection.createSession()'
 * <p>
 * 
 * 
 * @class
 * @memberof module:rtcomm.connector
 *
 * Arguments are in the form of a 'config' object:
 *
 * @param  {object} config 
 *
 * When created due to an INBOUND connection:
 *   
 * 
 * @private
 */
var SigSession = function SigSession(config) {

  /* Instance Properties */
  this.objName = 'SigSession';
  this.endpointconnector = null;
  this.id = null;
  this.toEndpointID = null;
  this.message = null;
  this.toTopic = null;
  this.type = 'normal'; // or refer
  this.referralDetails = null;
  this.appContext = null;

  if (config) {
    if (config.message && config.message.sigSessID) {

      // We are INBOUND. 
      this.message = config.message;
      this.id = config.message.sigSessID;
      this.toEndpointID = config.fromEndpointID || null;
      this.toTopic = config.toTopic || config.message.fromTopic || null;

      if (config.message.peerContent && config.message.peerContent.type === 'refer') {
        this.type = 'refer';
        this.referralDetails = config.message.peerContent.details;
      }
   
    }
   
    this.id = this.id || config.id;
    this.toTopic = this.toTopic || config.toTopic;
    this.appContext = this.appContext|| config.appContext;
  } 
  
  this.id = this.id || generateUUID();
 
  this.events = {
      'starting':[],
      'started':[],
      'failed':[],
      'stopped':[],
      'message':[],
      'ice_candidate':[],
      'have_pranswer':[],
      'pranswer':[],
      'finished':[]
  };
  // Initial State
  this.state = 'stopped';
  // Default our timeout waiting for initial start to 30 seconds.
  this.timeout = 30000; 
  
  

};


SigSession.prototype = util.RtcommBaseObject.extend((function() {
  /** @lends module:rtcomm.connector.SigSession.prototype */
  return { 
    /** 
     * Init method
     * @param config  -- message:message, fromEndpointID: endpointid, toTopic: toTopic
     */
    
    _setupQueue: function _setupQueue() {
      this._messageQueue = {
          'messages': [],
          'processing': false            
      };
      
      this.on('started', this._processQueue.bind(this));
      this.on('have_pranswer', this._processQueue.bind(this));
      this.on('pranswer', this._processQueue.bind(this));
      
    },
    _processQueue : function _processQueue() {
        var q = this._messageQueue.messages;
        var processingQueue = this._messageQueue.processing;
        if (processingQueue) {
          return;
        } else {
          processingQueue = true;
          l('DEBUG') && console.log(this+'.processQueue processing queue... ', q);
          q.forEach(function(message){
            this.send(message);
          }.bind(this));
          q = [];
          processingQueue=false;
        }
      },
    /**
     * 
     * start must be called to send the first message.
     * options are:
     * 
     *  config = {toEndpointID: something, sdp:  }
     */
    start : function(config) {
      this._setupQueue();
      l('DEBUG') && console.log('SigSession.start() using config: ', config);
      var toEndpointID = this.toEndpointID;
      var sdp = null;
      if (config) {
        this.toEndpointID = toEndpointID = config.toEndpointID || toEndpointID;
        sdp = config.sdp || null;
      }
      this.state = 'starting';
      console.log('toEnpdointID is:'+toEndpointID);
      if (!toEndpointID) {
        throw new Error('toEndpointID is required in start() or SigSession() instantiation');
      }  

      /*
       * If we are new, (no message...) then we shoudl create START and 
       *  a Transaction and send it....
       *  and establish an on('message');
       *    
       */
      if (!this.message) {
        this.message = this.createMessage('START_SESSION');
        this.message.peerContent = sdp || null;
        if (this.appContext) {
          this.message.appContext = this.appContext
        }
      }
      var session_started = function(message) {
        // our session was successfully started, if Outbound session, it means we 
        // recieved a Response, if it has an Answer, we need to pass it up.
        l('DEBUG') && console.log(this+'.sessionStarted!  ', message);
        this.state = 'started';
        this._startTransaction = null;
        //  this.processMessage(message);
        // if Inbound it means we SENT an answer. and have 'FINISHED' the transaction.
        this.emit('started', message.peerContent);
      };

      var session_failed = function(message) {
        this._startTransaction = null;
        this.state = 'stopped';
        console.error('Session Start Failed: ', message);
        this.emit('failed', message);
      };
      
      this._startTransaction = this.endpointconnector.createTransaction(
          { message: this.message,
            timeout: this.timeout
          },
          session_started.bind(this), 
          session_failed.bind(this));
      this._startTransaction.toTopic = this.toTopic || null;
      this._startTransaction.on('message', this.processMessage.bind(this));
      this._startTransaction.on('finished', function() {
        this._startTransaction = null;
      }.bind(this)
      );
     // this._startTransaction.listEvents();
      this._startTransaction.start();
      return this;
    },
    /*
     * Finish the 'Start'
     */
    respond : function(/* boolean */ SUCCESS, /* String */ message) {
      
      /* 
       * Generally, respond is called w/ a message, but could just be a boolean indicating success.
       * if just a message passed then default to true
       * 
       */
      if (SUCCESS && typeof SUCCESS !== 'boolean') {
        message = SUCCESS;
        SUCCESS = true;
      }
      
      // If it isn't set at all, make sure it is true;
      SUCCESS = SUCCESS || true;

      l('DEBUG') && console.log(this+'.respond() Respond called with message', message);
      l('DEBUG') && console.log(this+'.respond() Respond called using this', this);
      var messageToSend = null;
      if (this._startTransaction) {
        messageToSend = this.endpointconnector.createResponse('START_SESSION');
        messageToSend.transID = this._startTransaction.id;
        messageToSend.sigSessID = this.id;
        
        if (SUCCESS) { 
          messageToSend.result = 'SUCCESS';
          messageToSend.peerContent = (this.type === 'refer') ? {type: 'refer'} : message; 
        } else {
          messageToSend.result = 'FAILURE';
          messageToSend.reason = message || "Unknown";
        }
        // Finish the transaction
        this._startTransaction.finish(messageToSend);
        this.state = 'started';
        this.emit('started');
      } else {
        // No transaction to respond to.
        console.log('NO TRANSACTION TO RESPOND TO.');
      }
    },
    /**
     *  send a pranswer
     */
    pranswer : function(peerContent) {
      peerContent = peerContent || {'type':'pranswer'};
      this.state = 'pranswer';
      this.send(peerContent);
      this.emit('pranswer');
    },

    stop : function() {
      var message = this.createMessage('STOP_SESSION');
      l('DEBUG') && console.log(this+'.stop() stopping...', message);
      this.endpointconnector.send({message:message});
      // Let's concerned persons know we are stopped
      this.state = 'stopped';
      this.emit('stopped');
      // We are 'finished' - this is used to clean us up by who created us.
      this.emit('finished');
    },

    /** 
     * Send a message, but we may care about the type, we will infer it
     * based on the content.
     * 
     */
    send :  function(message) {
      var messageToSend = null;
      if (message && message.rtcommVer && message.method) {
        // we've already been cast... just send it raw...
        messageToSend = message;
      } else {
        messageToSend = this.createMessage(message);
       // messageToSend.peerContent = message;
      }
      var transaction = this._startTransaction || null;
      var queue = !(this.state === 'started' || this.state === 'have_pranswer' || this.state === 'pranswer');
      if (queue && messageToSend.method === 'MESSAGE') {
        // Queuing message
        l('DEBUG') && console.log(this+'.send() Queueing message: ', messageToSend);
        this._messageQueue.messages.push(messageToSend);
      } else {
        if (transaction){
          l('DEBUG') && console.log(this+'.send() Sending using transaction['+transaction.id+']', messageToSend);
          transaction.send(messageToSend);
        } else {
          l('DEBUG') && console.log(this+'.send() Sending... ['+this.state+']', messageToSend);
          // There isn't a transaciton, delete transID if it is there...
          if (messageToSend.hasOwnProperty('transID')) {
            delete messageToSend.transID;
          }
          this.endpointconnector.send({message:messageToSend}); 
        }
      }
    },
    
    createMessage : function(object) {
      // We create messages for a sigSession... 
      // generally, this is what we should send, peerContent.
      var peerContent = null;
      
      // object could be a RAW Message... 
      // Object could be a peerContent type of message {type:offer|answer/icecandidate/user sdp/candidate/userdata: }
      //   where could infer our message type.
      // object could be a type we are going to set content...
      if (object && object.type ) { 
        peerContent = object;
      }
     
      var type = 'MESSAGE';
      if (peerContent) {
        type = peerContent.type === 'pranswer' ? 'PRANSWER' : 'MESSAGE';
      } else {
        type = object;
      }
      
      var message = this.endpointconnector.createMessage(type);
      message.toEndpointID = this.toEndpointID;
      message.sigSessID = this.id;
      message.peerContent = peerContent ? object : null;
      return message;
      
    },
    getState : function(){
      return this.state;
    },

    processMessage : function(message) {
      // Process inbound messages. Should not accept these if we ar not in STARTED or HAVE_PRANSWER 
      // HAVE_PRANSWER could mean we sent or received the PRANSWER 
      // 
      l('DEBUG') && console.log(this + '.processMessage() received message: ', message);
      // We care about the type of message here, so we will need to strip some stuff, and may just fire other events.
      // If our fromTopic is dfferent than our toTopic, then update it.

      this.toTopic = (message.fromTopic !== this.toTopic) ? message.fromTopic : this.toTopic;

      switch(message.method) {
      case 'PRANSWER':
        // change our state, emit content if it is there.
        this.state = 'have_pranswer';
        this.emit('have_pranswer', message.peerContent);
        break;
      case 'ICE_CANDIDATE':
        this.emit('ice_candidate', message.peerContent);
        break;
      case 'STOP_SESSION':
        this.state='stopped';
        this.emit('stopped', message.peerContent);
        this.emit('finished');
        break;
      case 'MESSAGE':
       /* l('DEBUG') && console.log('Emitting event [message]', message.peerContent);
        if (typeof this.emit === 'function') {
          console.log('emit is a function!');
        } */
        this.emit('message', message.peerContent);
        break;
      default:
        console.error('Unexpected Message, dropping... ', message);
      }

    }
  };
})());

/**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
/**
   * @class
   * @memberof module:rtcomm.connector
   *
   * @classdesc
   * A Transaction is a conversation that requires a response.
   * /**
   * @param options   message: message, timeout: timeout
   * @param {callback} cbSuccess called when transaction is successful 
   * @param {callback} cbFailure 
   * 
   * @event finished Emitted when complete... can also use onSuccess.
   * @event message 
   * 
   * 
   * @private
   */
var Transaction = function Transaction(options, cbSuccess, cbFailure) {
  var message, timeout;
  if (options) {
    message = options.message || null;
    timeout = options.timeout || null;
  }
  /* Instance Properties */
  this.objName = "Transaction";
  this.events = {'message': [],
      'finished':[]};
  this.timeout = timeout || null;
  this.outbound = (message && message.transID) ? false : true;
  this.id = (message && message.transID) ? message.transID : generateUUID(); 
  this.method = (message && message.method) ? message.method : 'UNKNOWN'; 
  this.toTopic = null;
  this.message = message;
  this.onSuccess = cbSuccess || function(object) {
    console.log(this+' Response for Transaction received, requires callback for more information:', object);
  };
  this.onFailure = cbFailure || function(object) {
    console.log(this+' Transaction failed, requires callback for more information:', object);
  };
  l('DEBUG') && console.log('Are we outbound?', this.outbound);
};

Transaction.prototype = util.RtcommBaseObject.extend(
   /** @lends module:rtcomm.connector.Transaction.prototype */
    {
  /*
   *  A Transaction is something that may require a response, but CAN receive messages w/ the same transaction ID 
   *  until the RESPONSE is received closing the transaction. 
   *  
   *  The types of transactions correlate with the types of Messages with the Session being the most complicated.
   *  
   *  Transaction management... 
   *  
   *  TODO:  Inbound Starts... 
   *  
   *  
   */
  /*
   * Instance Methods
   */
 
  getInbound: function() {
    return !(this.outbound);
  },
  /**
   * Start a transaction
   * @param [timeout] can set a timeout for the transaction
   */
  start: function(timeout) {
    l('TRACE') && console.log(this+'.start() Starting Transaction for ID: '+this.id);
    if (this.outbound) {
      this.message.transID = this.id;
      this.send(this.message);  
    } else {
      l('DEBUG') && console.log('inbound Transaction -- nothing to send in start()');
    }
  },
  /**
   * send a message over the transaction
   */
  send: function(message) {
    l('TRACE') && console.log(this+'.send() sending message: '+message);
    if(message) {
      message.transID = message.transID || this.id;
      l('DEBUG') && console.log('Transaction.send() ids...'+message.transID +' this.id '+ this.id+'toTopic: '+this.toTopic);
      if (message.transID === this.id) {
        this.endpointconnector.send({message: message, toTopic:this.toTopic});
      } else {
        l('DEBUG') && console.log(this+'.send() Message is not part of our tranaction, dropping!', message);
      }
    } else {
      console.error('Transaction.send() requires a message to be passed');
    }
  },
  /**
   * Finish the transaction, message should be a RESPONSE.
   */
  finish: function(rtcommMessage) {
    // Is this message for THIS transaction?
    l('DEBUG') && console.log(this+'.finish() Finishing transction with message:',rtcommMessage);
    // if there isn't an id here, add it. 
    rtcommMessage.transID = rtcommMessage.transID || this.id;
    if (this.id === rtcommMessage.transID &&
        rtcommMessage.method === 'RESPONSE' && 
        this.method === rtcommMessage.orig) {
      if (this.outbound) {
        if (rtcommMessage.result  === 'SUCCESS' && this.onSuccess ) {
          
          this.onSuccess(rtcommMessage);
        } else if (rtcommMessage.result === 'FAILURE' && this.onFailure) {
          this.onFailure(rtcommMessage);
        } else {
          console.error('Unknown result for RESPONSE:', rtcommMessage);
        }
      } else {
     // If we are inbound, then send the message we have and finish the transaction
        this.send(rtcommMessage);
      }
      this.emit('finished');

    } else {
      console.error('Message not for this transaction: ', rtcommMessage);
    }
  }
});


  return { EndpointConnection:EndpointConnection, MessageFactory:MessageFactory, RtcommService:RtcommService };
  
})();


/**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
/** 
 * @class
 * @memberof module:rtcomm
 * @classdesc
 * Provides Services to register a user and create RtcommEndpoints
 * <p>
 * This programming interface lets a JavaScript client application use a {@link module:rtcomm.RtcommEndpoint|Real Time Communication Endpoint} 
 * to implement WebRTC simply. When {@link module:rtcomm.EndpointProvider|instantiated} & {@link module:rtcomm.RtcommEndpointProvider#init|initialized} the 
 * RtcommEndpointProvider connects to the defined MQTT Server and subscribes to a unique topic that is used to receive inbound communication.   
 * <p>
 * See the example in {@link module:rtcomm.EndpointProvider#init|EndpointProvider.init()}
 * <p>
 * 
 * @requires {@link mqttws31.js}
 *   
 */ 
var EndpointProvider =  function EndpointProvider() {

  var MISSING_DEPENDENCY = "RtcommEndpointProvider Missing Dependency: ";
  if (!util) { throw new Error(MISSING_DEPENDENCY+"rtcomm.util");}
  if (!connection) { throw new Error(MISSING_DEPENDENCY+"rtcomm.connection");}

  /** @lends module:rtcomm.EndpointProvider */

  /* configuration */
  var defaultConfig = {
      appContext: 'rtcomm',
      server:null,
      port: 1883,
      userid : null,
      connectorTopicName : "endpointConnector",
      connectorTopicPath: "/rtcomm/",
      credentials : { user: "", password: ""},
      register: false,
      createEndpoint: false
  };

  this.config = defaultConfig;
  // Internal objects
  this.ready = false;
  
  // Default rtcommEndpoint (First instance created)
  this.defaultRtcommEndpoint = null;
  
  this.events = { 
      /**
       * A new RtcommEndpoint was created from an inbound 
       * @event module:rtcomm.EndpointProvider#newendpoint
       * @property {module:rtcomm#RtcommEndpoint}
       */
      'newendpoint': []};
  
  /** services supported by the EndpointConnection, populated in init()*/
  this.services = null; 

  /** 
   * EndpointProvider Init config object
   * @typedef  {Object} module:rtcomm.EndpointProvider~InitOptions
   * @property {string} server MQTT Server
   * @property {string} [port=1883] MQTT Server Port 
   * @property {string} userid User ID or Identity
   * @property {string} [connectorTopicName=endpointConnection] connectorTopicName on rtcomm server
   * @property {string} [connectorTopicPath=/rtcomm/] MQTT Path to prefix connectorTopicName with and register under
   * @property {boolean} [register=false] Automatically register
   * @property {boolean} [createEndpoint=false] Automatically create a {@link module:rtcomm.RtcommEndpoint|RtcommEndpoint}
   */

  /** init method
   *  This method is required to be called prior to doing anything else.
   * @param  {module:rtcomm.EndpointProvider~InitOptions} config - Configuration object for init
   * @param {function} [onSuccess] Callback function when init is complete successfully.
   * @param {function} [onFailure] Callback funtion if a failure occurs during init
   * @param {function} [status]  Callback function to monitor status of init
   * 
   * @example
   * var endpointProvider = new ibm.rtcomm.RtcommEndpointProvider(); 
   * var endpointProviderConfig = {
   *   server : 'broker.mqttdashboard.com',       
   *   userid : 'ibmAgent1@mysurance.org',
   *   connectorTopicName : 'endpointConnector',   
   *   connectorTopicPath : '/rtcomm/', 
   *   port : 8000,                          
   *   register: true,                     
   *   createEndpoint : true,                   
   *   credentials : null                  
   * };
   *
   * // Initialize the Service. [Using onSuccess/onFailure callbacks]
   * // This initializes the MQTT layer and enables inbound Communication.
   * var rtcommEndpoint = null;  
   * endpointProvider.init(endpointProviderConfig, 
   *    function(object) { //onSuccess
   *        console.log('init was successful, rtcommEndpoint: ', object);
   *        rtcommEndpoint = object;
   *    },
   *    function(error) { //onFailure
   *       console.error('init failed: ', error);
   *      }
   * );
   * 
   */
  this.init = function init(options, cbSuccess, cbFailure) {
    // You can only be init'd 1 time, without destroying reconnecting.
    if (this.ready) {
      l('INFO') && console.log('EndpointProvider.init() has been called and the object is READY');
      return true;
    }
    var requiredConfig = { server: 'string', port: 'number', userid: 'string'};
    var config = this.config;
    var endpointProvider = this;
    if (options) {
      // validates REQUIRED initOptions upon instantiation.
      /*global _validateConfig: false */
      validateConfig(options, requiredConfig);
      // handle logLevel passed in...
      if (options.logLevel) {
        setLogLevel(options.logLevel);
        delete options.logLevel;
      }
      applyConfig(options, config);

    } else {
      throw new Error("RtcommEndpointProvider initialization requires a minimum configuration: " + JSON.stringify(requiredConfig));
    }

    cbSuccess = cbSuccess || function(message) {
      console.log(endpointProvider+'.init() Default Success message, use callback to process:', message);
    };
    cbFailure = cbFailure || function(error) {
      console.log(endpointProvider+'.init() Default Failure message, use callback to process:', error);
    };
    this.userid = config.userid;

    this.endpointConnection = new connection.EndpointConnection({
      server: config.server,
      port: config.port,
      userid: config.userid,
      connectorTopicName: config.connectorTopicName,
      connectorTopicPath: config.connectorTopicPath
    });

    var endpointConnection = this.endpointConnection;
    endpointConnection.setLogLevel(getLogLevel());


    var onSuccess = function(message) {
      var returnObj = {
          'ready': true,
          'registered': false,
          'endpointObj': null
      };
      this.ready = true;
      
      endpointConnection.service_query(
          /* onSuccess */ function(services) {
            // Returned services
            l('DEBUG') && console.log('Supported services are: ', services);
            this.services = services || null;
            
          }.bind(this),
          /* onFailure */ function(error){
            console.error('Unable to lookup supported services');
          });
     
      if (config.register) {
        endpointConnection.register(config.appContext, 
            function(message) {
          returnObj.registered = true;
          if (config.createEndpoint) {
            returnObj.endpoint  = endpointProvider.createRtcommEndpoint();
            cbSuccess(returnObj);
          } else {
            cbSuccess(returnObj);
          }
        }, 
        function(error) {
          cbFailure(error);
        });
      } else {
        cbSuccess(returnObj);
      }
    };
    var onFailure = function(error) {
      this.ready = false;
      cbFailure(error);
    };

    endpointConnection.on('newsession', function(session) {
      /*
       * What to do on an inbound request.
       * 
       * Options:
       *  Do we have a default endpoint?  if so, just give the session to it. 
       *  
       *  if that endpoint is busy, create a new endpoint and emit it.
       *  
       *  If there isn't a endpoint, create a Endpoint and EMIT it.
       *
       */  
      if(session) {
        console.log("Handle a new incoming session: ", session);
        var endpoint = endpointProvider.defaultRtcommEndpoint;
        if (endpoint && endpoint.available) {
          console.log('using an existing endpoint...', endpoint);
          endpoint.newSession(session);
        } else {
          endpoint = endpointProvider.createRtcommEndpoint();
          endpoint.newSession(session);
          endpointProvider.emit('newendpoint', endpoint);
        }
      } else {
        console.error('newsession - expected a session object to be passed.');
      }
    });
    
    endpointConnection.on('message', function(message) {
      if(message) {
        console.log("TODO:  Handle an incoming message ", message);
      }
    });
  
    // Connect!
    endpointConnection.connect( onSuccess.bind(this), onFailure.bind(this));
  
    
  };  // End of RtcommEndpointProvider.init()


  /** 
   * @typedef {object} module:rtcomm.EndpointProvider~EndpointConfig 
   *  @property {boolean} [audio=true] Support audio in the PeerConnection - defaults to true
   *  @property {boolean} [video=true] Support video in the PeerConnection - defaults to true
   *  @property {boolean} [data=true]  Support data in the PeerConnectio - defaults to true
   *  @property {String}  [context='none'] Context for the Handler. Used in messages and with the server. defaults to 'none'
   */

  /**
   * createRtcommEndpoint - Factory method that returns a RtcommEndpoint object to be used
   * by a UI component.  
   * 
   *  The rtcommEndpoint object provides an interface for the UI Developer to attach Video and Audio input/output. 
   *  Essentially mapping a broadcast stream(a MediaStream that is intended to be sent) to a RTCPeerConnection output
   *  stream.   When an inbound stream is added to a RTCPeerConnection, then the RtcommEndpoint object also informs the 
   *  RTCPeerConnection where to send that stream in the User Interface.  
   *
   * @param {module:rtcomm.EndpointProvider~EndpointConfig} endpointConfig - Configuration to initialize endpoint with. 
   *  
   * @returns {module:rtcomm.RtcommEndpoint|RtcommEndpoint}  A RtcommEndpoint Object
   * 
   * @example 
   *  var endpointConfig = { 
   *    audio: true, 
   *    video: true, 
   *    data: false, 
   *    };
   *  rtcommEndpointProvider.createRtcommEndpoint(endpointConfig);
   *  
   *  @throws Error
   */
  this.createRtcommEndpoint = function createRtcommEndpoint(endpointConfig) {
    var defaultConfig = {
        autoAnswer: false,
        appContext: this.config.appContext,
        audio: true,
        video: true,
        data: true,
        parent:this,
        userid: this.userid
    };
    var objConfig = defaultConfig;
    applyConfig(endpointConfig, objConfig);

    // Reflect this into the RtcommEndpoint.
    l('DEBUG') && console.log(this+'.createRtcommEndpoint using config: ', objConfig);
    var endpoint = Object.create(RtcommEndpoint);
    endpoint.init(objConfig);
    // Register
    try {
      this.defaultRtcommEndpoint = this.defaultRtcommEndpoint || endpoint;
      return endpoint;
    } catch(e){
      throw new Error(e);
    }
  };
  
  this.destroy =    function() {
    //TODO:  Add EndpointRegistry... 
    // Unregister (be nice...)
    
    this.unregister();
    l('DEBUG') && console.log(this+'.destroy() Finished cleanup of endpointRegistry');
    this.endpointConnection.destroy();
    l('DEBUG') && console.log(this+'.destroy() Finished cleanup of endpointConnection');
    
  }; 
   
  // exposing module global functions for set/get loglevel
  this.setLogLevel = setLogLevel;
  this.getLogLevel = getLogLevel;
  /** 
   *  Register the 'userid' used in {@link module:rtcomm.RtcommEndpointProvider#init|init} with the
   *  rtcomm service so it can receive inbound requests.
   *
   *  @param {function} [onSuccess] Called when register completes successfully with the returned message about the userid                          
   *  @param {function} [onFailure] Callback executed if register fails, argument contains reason.
   */
  this.register = function(appContext, success, failure) {
    var cbSuccess, cbFailure;
    if (typeof appContext === 'function') {
      cbFailure = success;
      cbSuccess = appContext;
      appContext = this.config.appContext;
     } else {
       this.config.appContext = appContext;
       cbSuccess = success;
       cbFailure = failure;
     }
    console.log('appContext is:'+ appContext);
    console.log('cbSuccess is:'+ cbSuccess);
    console.log('cbFailure is:'+ cbFailure);
    
    if (!this.ready) {
      throw new Error('Not Ready! call init() first');
    }
    this.endpointConnection.register(appContext, cbSuccess, cbFailure);
  };
  /** 
   *  Unregister from the server
   */
  this.unregister = function() {
    this.endpointConnection.unregister();
  };
  
  this.currentState = function() {
    return {
      states:  this._private,
      config : this.config,
      defaultRtcommEndpoint: this.defaultRtcommEndpoint
    };

  };

}; // end of constructor

EndpointProvider.prototype = util.RtcommBaseObject.extend({});


/**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
// rtcservice & util should be defined here:
/*global util:false*/
var logging = new util.Log(),
    setLogLevel = logging.s,
    getLogLevel = logging.g,
    l = logging.l,
    generateUUID = util.generateUUID,    
    validateConfig = util.validateConfig,
    applyConfig = util.applyConfig,
    /*global log: false */
    log = logging.log;

/* function log() {
          // I want to log CallingObject[id].method Message [possibly an object]

          var object = {},
              method = '<none>',
              message = null,
              remainder = null,
              logMessage = "";

          var args = [].slice.call(arguments);

          if (args.length === 0 ) {
            return;
          } else if (args.length === 1 ) {
            // Just a Message, log it...
            message = args[0];
          } else if (args.length === 2) {
            object = args[0];
            message = args[1];
          } else if (args.length === 3 ) {
            object = args[0];
            method = args[1];
            message = args[2];
          } else {
            object = args.shift();
            method = args.shift();
            message = args.shift();
            remainder = args;
          }

          if (object) {
            logMessage = object.toString() + "." + method + ' ' + message;
          } else {
            logMessage = "<none>" + "." + method + ' ' + message;
          }
          // Ignore Colors...
          if (object && object.color) {object.color = null;}
          
          var css = "";
          if (object && object.color) {
            logMessage = '%c ' + logMessage;
            css = 'color: ' + object.color;
            if (remainder) {
              console.log(logMessage, css, remainder);
            } else {
              console.log(logMessage,css);
            }
          } else {
            if (remainder) {
              console.log(logMessage, remainder);
            } else {
              console.log(logMessage);
            }
          }
        }; // end of log/ 
        */
    
        
    
/**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
/** 
 *  @memberof module:rtcomm
 *  @description
 *  This object can only be created with the {@link module:rtcomm.RtcommEndpointProvider#createRtcommEndpoint|createRtcommEndpoint} function.
 *  <p>
 *  The rtcommEndpoint object provides an interface for the UI Developer to attach Video and Audio input/output. 
 *  Essentially mapping a broadcast stream(a MediaStream that is intended to be sent) to a RTCPeerConnection output
 *  stream.   When an inbound stream is added to a RTCPeerConnection, then this also informs the RTCPeerConnection 
 *  where to send that stream in the User Interface.  
 *  <p>
 *  See the example under {@link module:rtcomm.RtcommEndpointProvider#createRtcommEndpoint|createRtcommEndpoint}
 *  @constructor
 *  
 *  @extends  module:rtcomm.util.RtcommBaseObject
 */  
var RtcommEndpoint = util.RtcommBaseObject.extend((function() {
  
  var validMediaElement = function(element) {
    return( (typeof element.srcObject !== 'undefined') ||
        (typeof element.mozSrcObject !== 'undefined') ||
        (typeof element.src !== 'undefined'));
  };



  /*
   * Assign getUserMedia, attachMediaStream as private class functions
   */
  var getUserMedia, attachMediaStream,detachMediaStream;
  /* globals URL:false */
  if (navigator && navigator.mozGetUserMedia) {
    getUserMedia = navigator.mozGetUserMedia.bind(navigator);
    // Attach a media stream to an element.
    attachMediaStream = function(element, stream) {
      l('DEBUG') && console.log("FIREFOX --> Attaching media stream");
      element.mozSrcObject = stream;
      element.play();
    };
    detachMediaStream = function(element) {
      l('DEBUG') && console.log("FIREFOX --> Detaching media stream");
      if (element) {
     
        element.mozSrcObject = null;
        console.log('Element is: ', element);
      }
    };

  } else if (navigator && navigator.webkitGetUserMedia) {
    getUserMedia = navigator.webkitGetUserMedia.bind(navigator);
    attachMediaStream = function(element, stream) {
      if (typeof element.srcObject !== 'undefined') {
        element.srcObject = stream;
      } else if (typeof element.mozSrcObject !== 'undefined') {
        element.mozSrcObject = stream;
      } else if (typeof element.src !== 'undefined') {
        element.src = URL.createObjectURL(stream);
      } else {
        console.log('Error attaching stream to element.');
      }
    };
    detachMediaStream = function(element) {
      if (element) {
        if (typeof element.srcObject !== 'undefined') {
          element.srcObject = null;
        } else if (typeof element.mozSrcObject !== 'undefined') {
          element.mozSrcObject = null;
        } else if (typeof element.src !== 'undefined') {
          element.src = null;
        } else {
          console.log('Error attaching stream to element.');
        }
      }
    };
  } else {
    console.log("Browser does not appear to be WebRTC-capable");
  }
  
  /** @lends module:rtcomm.RtcommEndpoint.prototype */
  return {
    
    _initialized: false,
    /** initialize the object */
    init: function(config) { 
      /* Object to store private information */
      this._private =  {
          uuid: generateUUID(),
          autoAnswer: false,
          audio: true,
          video: true,
          data: true,
          appContext: 'none',
          userid: null,
          parent: null,
          inboundMedia: null,
          attachMedia: false
      };
      
      /** @typedef {object} module:rtcomm#RtcommEvent 
       *  @property {string} name - name of event
       *  @property {object} object - an object passed with the event
       *  @property {message} message - a message associated with the event
       */
      
      
      this.events = {
          /**
           * A connection to a peer has been established
           * @event module:rtcomm.RtcommEndpoint#connected
           * @property {module:rtcomm#RtcommEvent}
           */
          "connected": [],
          "refer": [],
          /**
           * The connection to a peer has been closed
           * @event module:rtcomm.RtcommEndpoint#disconnected
           * @property {module:rtcomm#RtcommEvent}
           */
          "disconnected": [],
          /**
           * A peer has been reached, but not connected (inbound/outound)
           * @event module:rtcomm.RtcommEndpoint#ringing
           * @property {module:rtcomm#RtcommEvent}
           */
          "ringing": [],
          /**
           * A connection is being attempted (outbound only)
           * @event module:rtcomm.RtcommEndpoint#trying
           * @property {module:rtcomm#RtcommEvent}
           */
          "trying": [],
          /**
           * An inbound connection is being requested.
           * @event module:rtcomm.RtcommEndpoint#incoming
           * @property {module:rtcomm#RtcommEvent}
           */
          "incoming": [],
          /**
           * A message has arrived from a peer
           * @event module:rtcomm.RtcommEndpoint#message
           * @property {module:rtcomm#RtcommEvent}
           */
          'message': []
      };

      console.log('LOG LEVEL in RtcommEndpoint is: '+getLogLevel());

      l('DEBUG') && console.log('LOG LEVEL in RtcommEndpoint is: '+getLogLevel());

      l('DEBUG') && console.log(this+'.init() Applying config to this._private ', config, this._private);

      if (config) {
        this.update = (config.update)?config.update: this.update;
        delete config.update;
        applyConfig(config, this._private);
      }

      this.endpointConnection = this._private.parent.endpointConnection;

      /* inbound and outbound Media Element DOM Endpoints */
      this.media = {
          In: null,
          Out: null
      };
      this.available = true;
      // Our events we generate OUTBOUND.
      // needed?
      this.localStream=null;
      this._initialized = true;
    },

    update: function() { console.log('Default function, should have been overridden');},

    reset: function() {
      this.disconnect();
      this.localStream && this.localStream.stop();
      detachMediaStream(this.getMediaIn());
      detachMediaStream(this.getMediaOut());
    },
    
    /**
     *  Destroy this endpoint.  Cleans up everything and disconnects any and all connections
     *  
     */
    
    destroy : function() {
      l('DEBUG') && console.log(this+'.destroy Destroying RtcommEndpoint');
    },

    newSession : function(session) {
      // This is how we get an inbound session.
      // If our session is not 'normal', i.e. it is a 3PCC session
      // then we need to behave differently:
      // should be just display 'RINGING' and let them create ANOTHER session.
      // 
      l('DEBUG') && console.log(this + '.newSession() new session called w/ ',session);
      
      if (this.available) {
        var event = 'incoming';
        
        if (session.type === 'refer') {
          l('DEBUG') && console.log(this + '.newSession() REFER, sending pranswer()');
    //      session.pranswer();
          event = 'refer';
        }
        
        this.conn = this.createConnection();
        this.conn.init({session:session});
        this.emit(event, this.conn);
      }
    },

    createConnection : function(config, onSuccess, onFailure) {

      if (!this._initialized) {
        throw new Error('Not Ready! call init() first');
      }
      // ourself is the rtcommEndpoint
      var rtcommEndpoint = this;
      config = config || {};
      config.rtcommEndpoint = rtcommEndpoint;
      // Call the ClientServide createConnection with correct context set and config;
      rtcommEndpoint.conn  = new WebRTCConnection({
        audio: this.getAudio(),
        video: this.getVideo(),
        data: this.getData(),
        appContext: this._private.appContext,
        toEndpointID: config.toEndpointID,
        rtcommEndpoint: rtcommEndpoint,
        endpointConnection: this.endpointConnection,
        onEvent: function(event) {
          // This type of event is event.name...
          rtcommEndpoint.emit(event.name, event);
        }
      });
      return rtcommEndpoint.conn;
    },

    // TODO:  Remove?
    /**
     * attachLocalMedia method used to validate internal setup and set things up if not already done.
     * 
     * The setup requires a mediaOut & mediaIn object w/ src attribute.  it also requires a localStream, or it will add it.
     * We should decouple this... 
     * 
     * @params {function} callback  Passed true/false if attachMedia is successful. If false, also gets a reason message.
     * 
     */
    attachLocalMedia : function(/*callback*/ cbFunction) {
      var callback = cbFunction || function(value,message) {
        message = message || "No Message";
        console.log(this+"attachLocalMedia.callback should be overridden:("+value+","+message+")");
      };
      var rtcommEndpoint = this;
      l('DEBUG') && console.log('rtcommEndpoint.attachLocalMedia(): Setting up the rtcommEndpoint:', this);
      if (this.getAudio() || this.getVideo()|| this.getData()) {
        if (this.getMediaIn() && this.getMediaOut()) {
          // Must be set...
          if (this.localStream) {
            l('DEBUG') && console.log('rtcommEndpoint.attachLocalMedia(): Have a localStream already, apply it.', this.localStream);
            // we have a local stream, proceed to make a call. 
            // TODO:  This following COMPARE is not browser agnostic
            if (URL.createObjectURL(this.localStream) === this.getMediaOut().src) {
              // We are connected and everthing... 
              l('DEBUG') && console.log('rtcommEndpoint.attachLocalMedia(): Already setup, skipping');
              callback(true);
            } else {
              // Apply the stream.
              l('DEBUG') && console.log('rtcommEndpoint.attachLocalMedia(): Applying Local Stream');
              rtcommEndpoint.attachMediaStream(rtcommEndpoint.getMediaOut(),rtcommEndpoint.localStream);
              callback(true);
            }
          } else {
            // No local stream, get it!
            l('DEBUG') && console.log('rtcommEndpoint.attachLocalMedia(): No Stream, getting one! audio:'+ this.getAudio()+' video: '+ this.getVideo());
            this.getUserMedia({audio: this.getAudio(), video: this.getVideo()} ,
                /* onSuccess */ function(stream) {
              console.log('getUserMedia returned: ', stream);
              rtcommEndpoint.localStream = stream;
              rtcommEndpoint.attachMediaStream(rtcommEndpoint.getMediaOut(),stream);
              callback(true);
            }, 
            /* onFailure */ function(error) {
              callback(false, "getUserMedia failed");
            });
          }
        } else {
          callback(false, "mediaIn & mediaOut must be set" );
        }
      } else {
        callback(true);
      }
    },

    /** 
     * Create a connection and send an offer to the id passed
     * <p>
     * This will go through event state "trying" --> "ringing" --> "connected", 
     * These should be handled through onEvent
     * 
     * @param {string} remoteId  - Id of CALLEE.
     * @throws Error No ID passed 
     */
    addEndpoint : function(/* String */ remoteId){
      // When call is invoked, we must have a RemoteID and we must have mediaIn & Out set. 
      // We need to confirm the stream is attached
      var rtcommEndpoint = this;
      l('DEBUG') && console.log(this + ".addEndpoint() Calling "+remoteId);
      if ( remoteId === null ) { throw new Error(".addEndpoint() requires an ID to be passed"); }

      this.attachLocalMedia(function(success, message) {
        if (success) {
          if (typeof rtcommEndpoint.createConnection === 'function') {
            rtcommEndpoint.createConnection({toEndpointID: remoteId, appContext: rtcommEndpoint.getAppContext()});
            rtcommEndpoint.conn.connect();
          } else {
            console.error("Don't know what to do, createConnection missing...");
          }        
        } else {
          throw new Error(".addEndpoint() failed: "+ message);
        }
      });
    },
    /** 
     *  Answers a call - [Sends an 'answer' on a connection that is inbound]
     *  There MAY be more than one connection present, if so, uses a passed ID to answer 
     *  the right connection
     *  
     *  @param {string} [id] Optional Id to answer.  Required if more than 1 connection
     *  
     *  @throws Error Could not find connection to answer
     */
    acceptEndpoint : function(id) {
      var rtcommEndpoint = this;
      l('DEBUG') && console.log(this + ".answer() invoked ");
      rtcommEndpoint.attachLocalMedia(function(success, message) {
        if (success) {
          var connection = rtcommEndpoint.getConnection(id);
          if(connection) {
            connection.connect();
          } else {
            throw new Error(".answer() could not find a valid connection to answer.");
          }
        } else {
          throw new Error(".answer() failed: "+ message);
        }
      });
    },

    /**  Destroys an existing connection. If there are more than one, then requires an ID
     *  
     *  @throws Error Could not find connection to hangup
     *  
     */
    disconnect : function() {
      if (this.conn  && this.conn.getState() !== 'DISCONNECTED') {
        this.conn.disconnect();
        this.conn = null;
      } else {
        this.conn = null;
      }

    },

    // UserMedia Methods
  
    getUserMedia : getUserMedia,
    attachMediaStream : attachMediaStream,
    detachMediaStream : detachMediaStream,

    getConnection: function() { return this.conn ;},

    /*jshint es5: true */
    /** Whether audio is enabled or not in the RtcommEndpoint.  
     * @type Boolean 
     * @throws Error Resulting Audio/Video/Data combination already exists for the context.
     * */
    getAudio: function() { return this._private.audio; },
    setAudio: function(/*boolean*/ value)  {
      if(this.update({audio: value}, this._private.uuid)) {
        this._private.audio = value;
      } else {
        throw new Error("Unable to set value, would create a registration that already exists");
      }
    },
    /** Whether Video is enabled or not in the RtcommEndpoint.  
     * @type Boolean 
     * @throws Error Resulting Audio/Video/Data combination already exists for the context.
     * */
    getVideo: function() { return this._private.video;},
    setVideo: function(/*boolean*/ value)  {
      if(this.update({video: value}, this._private.uuid)) {
        this._private.video = value;
      } else {
        throw new Error("Unable to set value, would create a registration that already exists");
      }
    },
    /** Whether data is enabled or not in the RtcommEndpoint.  
     * @type Boolean 
     * @throws Error Resulting Audio/Video/Data combination already exists for the context.
     * */
    getData: function() {return this._private.data;},
    setData: function(/*boolean*/ value)  {
      if(this.update({data: value}, this._private.uuid)) {
        this._private.data = value;
      } else {
        throw new Error("Unable to set value, would create a registration that already exists");
      }
    },
    /** context of the endpoint instance.  This is used to match nodes on endpoints so that each endpoint
     *  should have a node with the same context in order to communicate with each other. There can
     *  only be one context + audio/video/data combination. 
     *   
     *  @example
     *  // get the context
     *  var context = rtcommEndpoint.getAppContext();
     *  // set the context
     *  rtcommEndpoint.setAppContext("newcontext");
     *  
     *  @throws Error Context already exists
     */
    getAppContext:function() {return this._private.appContext;},
   
    /** Return userid associated with this RtcommEndpoint */
    getUserid: function() { return this._private.userid;},
    getUuid: function() {return this._private.uuid;},
    /** RtcommEndpoint is ready to initiate a connection
     * @type Boolean */
    isReady: function() {return this._private.parent.isReady();},
    /* autoAnswer - used for testing */
    getAutoAnswer: function() { return this._private.autoAnswer;},
    setAutoAnswer: function(value) { this._private.autoAnswer = value;},

    setInboundMediaStream: function(stream) {
      this._private.inboundMedia=URL.createObjectURL(stream);
      if (this.getMediaIn()) {
        this.attachMediaStream(this.getMediaIn(), stream);
      } 
    },
    getInboundMediaStream: function() { return this._private.inboundMedia;},

    /** 
     * DOM node to link the RtcommEndpoint inbound media stream to. 
     * @param {Object} value - DOM Endpoint with 'src' attribute like a 'video' node.
     * @throws Error Object does not have a src attribute
     */
    getMediaIn: function() {
      return this.media.In;
    },
    setMediaIn: function(value) {
      if(validMediaElement(value) ) {
        this.media.In = value;
        // if we already have an inboundMedia stream attached, attach it here.
        if (this._private.inboundMedia) {
          this.attachMediaStream(this.media.In, this._private.inboundMedia);
        }
      } else {
        throw new TypeError('Media Element object is invalid');
      }

    },
    /** 
     * DOM Endpoint to link outbound media stream to.
     * @param {Object} value - DOM Endpoint with 'src' attribute like a 'video' node.
     * @throws Error Object does not have a src attribute
     */
    getMediaOut: function() { return this.media.Out; },
    setMediaOut: function(value) {
      if(validMediaElement(value) ) {
        this.media.Out = value;
        // if we already have an inboundMedia stream attached, attach it here.
        if (this.localStream) {
          this.attachMediaStream(this.media.In, this.localStream);
        }
      } else {
        throw new TypeError('Media Element object is invalid');
      }
    },
    toString: function() {
      return "RtcommEndpoint["+this._private.uuid+"]";
    }
  }; // end of Return    

})());
 /**
 * Copyright 2014 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/ 
var WebRTCConnection = (function invocation() {
  
  var getIceServers = function(object) {
    // Expect object to look something like:
    // {"iceservers":{"urls": "stun:host:port", "urls","turn:host:port"} }
    
    var iceServers = [];
    var services = null;
    var servers = null;
    if (object && object.services && object.services.iceservers) {
      servers  = object.services.iceservers;
      if (servers && servers.iceURL) {
        var urls = [];
        servers.iceURL.split(',').forEach(function(url){
          urls.push({'url': url});
        });
        iceServers = {'iceServers':urls};
        return iceServers;
      } 
    } else {
      return  {'iceServers':[]};
    }
  };
  
  
  /**
   * @class
   * @memberof module:rtcomm.webrtc
   *
   * @classdesc
   * A WebRTCConnection is a connection from one peer to another encapsulating
   * an RTCPeerConnection and a SigSession
   *
   * 
   * @param {string}  [context] Option Context for the page
   * @param {boolean}  [audio] We want audio in our PeerConnection
   * @param {boolean}  [video] We want Video in our PeerConnection
   * @param {boolean}  [data]  We want Data in our PeerConnection
   * @param {string}  toEndpointID WHO We want to connect to
   * @param {string}  [context] A string representing an app/context/url  we are connecting from
   * @param {ibmrtc.rtcomm.RtcChannel} [channel] Channel to attach to
   * @param {ibmrtc.rtcomm.RtcMessage} [message] optional message to process on instantiation
   *
   * @throws  {String} Throws new Error Exception if invalid arguments
   * 
   * @private
   */
  
function WebRTCConnection(/* object */ config ) {


  /** @const */
  this.name = 'WebRTCConnection';

  var requiredConfig = { };

  /** Default parameter definition */
  this.endpointConnection = null;
  this.audio = false;
  this.video = false;
  this.data = false;
  this.appContext = null;
  this.rtcommEndpoint = null;
  this.toEndpointID = null;
  this.autoAnswer = false;
  
  this.streamAttached = false;
  // peer connection config
  this.pranswer = false;
  //TODO doesn't work yet. leave true.
  this.trickle = true;
  
  /** define our callbacks */
  //TODO Change this...
  this.onEvent = null;

  /** initialize variables */
  if (config) {
    // validates REQUIRED config upon instantiation.
    /* global _validateConfig: false */
    /* global _applyConfig: false  */
    validateConfig(config, requiredConfig);
    if (config.logLevel) {
      setLogLevel(config.logLevel);
      delete config.logLevel;
    }
    // Apply the Config to this object
    applyConfig(config, this);
  } else {
    throw new Error("WebRTCConnection instantiation requires a minimum configuration: " + JSON.stringify(requiredConfig));
  }

  this.STATES = { "READY": "Ready to Connect",
      "STARTED": "SigSession is connected, but no PeerConnection",
      "CONNECTED": "Connected to a target via a Signaling Session and has a PeerConnection connected. ",
      "DISCONNECTED":"Not connected to anything",
      "RINGING": "In Progress, waiting for a manual intervention (generally have pranswer, need answer)",
      "TRYING":"In progress",
      "FAILED": "Connection Failed"};

  /** Constant EVENT NAME of state  (note lowercase)  */

  this.EVENTS = {
      "ready": "Ready to connect",
      "connected":"Connected to %s",
      "ringing": "Waiting for an Answer",
      "trying": "Connecting to %s",
      "disconnected": "Disconnect from %s",
      "failed": "Connection Failed to %s"};

  this.state = "DISCONNECTED";
  // private
  this.ready = false;
  
  this._sigSession = null;
  this._peerConnection = null;
  
  this._referralSession = null;
  
  this.autoAnswer = this.rtcommEndpoint.getAutoAnswer();
  this.id = this.toEndpointID;
  
  /** Changes loglevel for the whole webrtc module */
  this.setLogLevel = setLogLevel;
  /** gets loglevel for the whole webrtc module */
  this.getLogLevel = getLogLevel;
  
  this.iceServers = null;
  
}  // End of Constructor


/* Prototype */
WebRTCConnection.prototype = function() {
  /**
   *  @memberof WebRTCConnection
   *  When we init, we attach our signalingSession and PeerConnection
   *
   *  If we are 'In Progress' meaning we are being init'd by our
   *  WebRTCClientService w/ a Channel & Message then we actually need to
   *  begin our SigSession so it can respond. Typically this should
   *  be w/ a 'pranswer'
   *
   *  @param {boolean} (caller) 'true' if caller, false, if callee
   *  @param {object} (session) a SigSession object created on inbound, don't need to create one.
   *
   *  @param {function} (onComplete) Callback executed when the init finishes.
   *  
   *  
   */
  var init = function(config) {

    var session = null,
    caller=true,
    onComplete = function(message) {
      console.log(this+'.init() is complete, override to process', message);
    };

    /* global log: false */
    /* global l: false */
    l('DEBUG') && console.log(this+'.init Initializing Connection with config: ', config);
    if (config){
      /* 
       * If there is a config.session - we need to check the type, if its 
       * 'refer' then this session is not our Session, we will create a new one.
       *  If its 'normal' then we are 'inbound'
       */
      if (config.session){
        if (config.session.type === 'normal') {
          session = config.session;
          this.appContext = config.session.appContext || "none";
          caller = false;
        } else if (config.session.type === 'refer') {
          this._referralSession = config.session;
          // Changes for REFER 
          this._referralSession.start();
          this._referralSession.pranswer();
        } else {
          console.error('Invalid Session passed: ', config.session);
        }
      }
      
      onComplete = config.onComplete || onComplete;
      
      l('DEBUG') && console.log(this+'.init caller is: ', caller);
      // If we have a endpoint attached, populate our variables from it.
      if (config.rtcommEndpoint) {
        this.rtcommEndpoint = config.rtcommEndpoint;
        this.audio = this.rtcommEndpoint.audio || false;
        this.video = this.rtcommEndpoint.video || false;
        this.data = this.rtcommEndpoint.data || false;
        this.iceServers = getIceServers(config.rtcommEndpoint);
      }
    } 
  
    if (this.rtcommEndpoint === null) {
      console.error("rtcommEndpoint required...");
      throw new Error("WebRTCConnection.init() - rtcommEndpoint required");
    }
    
    
    /*
     * If there is audio/video/data, we will create a peerconnection
     * Otherwise we can create JUST a signaling session.  This is 
     * really only practical when testing signaling.
     * 
     */
    if (this.audio || this.video || this.data) {
      // Create a peerconnection
      this._peerConnection =  createPeerConnection(this);
      if (this.attachLocalStream()) {
        l('DEBUG') && console.log('Successfully attached streams... ');
        l('DEBUG') && console.log('Local Streams: ' + JSON.stringify(this._peerConnection.getLocalStreams()));
        l('DEBUG') && console.log('Remote Streams: ' + JSON.stringify(this._peerConnection.getRemoteStreams()));
      }
    }
    // Create our SigSession, but not Beginning it - that will only happen
    // when we need to.
    
    session = session || createSignalingSession(this);
    this.toEndpointID = session.toEndpointID || this.toEndpointID;
    this.id = this.toEndpointID;
    addSessionCallbacks(this, session);
    this._sigSession = session;
   
    if (!caller) {
      var message = session.message;
      session.start();
      if (message && message.peerContent) {
        // If the peerCOntent is an 'offer' we will do our PC stuff.
        var content = message.peerContent;
    
        if (content.type === 'offer') {
          this._peerConnection.setRemoteDescription(new MyRTCSessionDescription(message.peerContent),
            /*success*/  function() {
              l('DEBUG') && console.log('Set Remote Description... should fire addstream event now... ');
              // Successfully set the Remote Description, create an answer.
              // this will also handle sending whatever is next. 
              /*
               * Defect:  If media hasn't been attached, then this answer will be bad in FF.  
               *   We only create this answer if we are going to send a REAL pranswer (which we 
               *   generally dont)
               */
              if (this.pranswer) {
                this._peerConnection.createAnswer(this._gotAnswer.bind(this), function(error) {
                  console.error('Failed to create an Answer: '+error);
                });
              } else {
                this._setState('RINGING');
                session.pranswer();
              }
           
            }.bind(this),
            function(error) {
              console.error('Failed Setting Remote Description', error);
          });
        } else {
          console.error('Not an offer, unsure what to do');
        }
      } else {
        // It is a start session, we will respond w/ a PRANSWER and someone can answer...
        // generally the case we are operating outside of a peerConnection.
        if (this.autoAnswer) {
          session.respond({'type':'answer', sdp:''});
        } else {
          session.pranswer();
        }
        //console.error('No message on inbound session, unsure what to do');
      }
    }
 
  }, // End of init()

  setRTCommEndpoint = function(rtcommEndpoint) {
    // It is possible to have this done automatically by the onComplete callback.  If it happens, we MAY need to answer...
    // Validate it has everything we should have in it..
    this.rtcommEndpoint = rtcommEndpoint;

  },
  /* 
   * This is executed by createAnswer.  Typically, the intent is to just send the answer
   * and call setLocalDescription w/ it.  There are a couple of variations though.
   * 
   * This also means we have applied (at some point) applie a remote offer as our RemoteDescriptor
   *
   * In most cases, we should be in 'have-remote-offer'
   * 
   *  We have 3 options here:
   *  (have-remote-offer)
   *  1.  start a session w/ a message 
   *  2.  start w/out a message
   *  3.  send message.
   *  
   *  // ANSWER
   *  // PRANSWER or REAL_PRANSWER
   *  
   *  
   *  
   */
  _gotAnswer =  function(desc) {
    
    l('DEBUG') && console.log(this+'.createAnswer answer created:  ', desc);

    var answer = null;
    var pcSigState = this._peerConnection.signalingState;
    var sessionState = this._sigSession.getState();

    var PRANSWER = (pcSigState === 'have-remote-offer') && (sessionState === 'starting');
    var RESPOND = this.AutoAnswer || sessionState === 'pranswer' || pcSigState === 'have-local-pranswer';

    l('DEBUG') && console.log(this+'.createAnswer._gotAnswer: pcSigState: '+pcSigState+' SIGSESSION STATE: '+ sessionState);
    
    if (RESPOND) {
      l('DEBUG') && console.log(this+'.createAnswer sending answer as a RESPONSE');
      this._setState('CONNECTED');
      this._sigSession.respond(true, desc);
    } else if (PRANSWER){
      l('DEBUG') && console.log(this+'.createAnswer sending PRANSWER');
      this._setState('RINGING');
      answer = {};
      answer.type = 'pranswer';
      answer.sdp = this.pranswer ? desc.sdp : '';
      desc = answer;
      this._sigSession.pranswer(desc);
    } else {
      l('DEBUG') && console.log(this+'.createAnswer sending ANSWER (renegotiation?)');
      // Should be a renegotiation, just send the answer...
      this._sigSession.send(desc);
    }
    // Should have been sent.
    l('DEBUG') && console.log('_gotAnswer: pcSigState: '+pcSigState+' SIGSESSION STATE: '+ sessionState);
    
    var SKIP = PRANSWER && answer && answer.sdp === '';
    if (!SKIP) {
      this._peerConnection.setLocalDescription(desc,/*onSuccess*/ function() {
        l('DEBUG') && console.log('setLocalDescription in _gotAnswer was successful', desc);
      }.bind(this), 
        /*error*/ function(message) {
        console.error(message);
    });

    }
  },

  /** Process inbound messages
   *
   *  These are 'PeerConnection' messages
   *  Offer/Answer/ICE Candidate, etc...
   */
  _processMessage = function(message) {
    
    var isPC = this._peerConnection ? true : false;
    
    if (!message) {
      return;
    }
    l('DEBUG') && console.log(this+"._processMessage Processing Message...", message);
   /* if (!this._peerConnection) {
      l('DEBUG') && log(this, '_processMessage', 'Dropping Message, no peerConnection', message);
      return;
    } */
    if (message.type) {
      switch(message.type) {
      case 'pranswer':
        /*
         * When a 'pranswer' is received, the target is 'THERE' and our state should
         * change to RINGING.
         *
         * Our PeerConnection is not 'stable' yet.  We still need an Answer.
         *
         */
        isPC && this._peerConnection.setRemoteDescription(new MyRTCSessionDescription(message));
        this._setState("RINGING");
        break;
      case 'answer':
        /*
         *  If we get an 'answer', we should be in a state to RECEIVE the answer,
         *  meaning we can't have sent an answer and receive an answer.
         *
         *  TODO:  Confirm we can receive this MESSAGE.
         *
         *  TODO:  Pull all of these Success/Failure callbacks somewhere.
         */
        l('DEBUG') && console.log(this+'._processMessage ANSWERING', message);
        /* global RTCSessionDescription: false */
        isPC && this._peerConnection.setRemoteDescription(new MyRTCSessionDescription(message),
            function() {
          l('DEBUG') && console.log("Successfully set the ANSWER Description");
        },
        function(error) {
          console.error('setRemoteDescription has an Error', error);
        });
        this._setState("CONNECTED");
        break;
      case 'offer':
        /*
         *  When we receive an offer here, we are NOT in the 'Session BEGIN' moment'
         *  There should be a session and our state should be READY or CONNECTED.
         *  
         * When an Offer is Received , we need to send an Answer, this may
         * be a renegotiation depending on our 'state' so we may or may not want
         * to include the UI. (meaning we wouldn't update it w/ a state change.
         */
        if (this.getState() === 'READY' || this.getState() === 'CONNECTED') {
          l('DEBUG') && console.log(this+'_processMessage offer renegotiating');
          isPC && this._peerConnection.setRemoteDescription(new MyRTCSessionDescription(message), 
              /*onSuccess*/ function() {
                this._peerConnection.createAnswer(this._gotAnswer.bind(this), function(error){
                  console.error('Failed to create Answer:'+error);
                });
              }.bind(this), 
              /*onFailure*/ function(error){
                console.error('setRemoteDescription has an Error', error);
              });
        } else {
          this._setState("RINGING");
        }
       
        break;
      case 'icecandidate':
        try {
          var iceCandidate = new MyRTCIceCandidate(message.candidate);
          l('DEBUG') && console.log(this+'_processMessage iceCandidate ', iceCandidate );
          isPC && this._peerConnection.addIceCandidate(iceCandidate);
        } catch(err) {
          console.error('addIceCandidate threw an error', err);
        }
        break;
      case 'user':
        this._emit(message.userdata);
        break;
      default:
        // Pass it up out of here...
        // TODO: Fix this, should emit something different here...
        this._emit(message);
     
      }
    } else {

      //TODO:  In both casses here, we need to consider emitting a raw message that is unprocessed...
      this._emit(message);
      l('DEBUG') && console.log(this+'_processMessage Unknown Message', message);
    }
  },
  
  attachLocalStream = function(callback) {
    // We should be able to get whether a Stream is attached from the peerconnection, 
    // however in Firefox, we can get here before the peerConnection REPORTS that a 
    // stream is attached w/ getLocalStreams().  In that case we could be in the middle
    // of addStream and if we call it again, then it messes up the peerConnection
    // 
    
    
    if (this.rtcommEndpoint && this.rtcommEndpoint.localStream) {
      // We have a localstream - we only support 1 local stream...  We should be able to add more streams, like music, etc... not yet. 
      if (this._peerConnection && !this.streamAttached) {
        l('DEBUG') && console.log(this+'.attachLocalStream() calling .addStream on peerConnection with: ', this.rtcommEndpoint.localStream);
        this._peerConnection.addStream(this.rtcommEndpoint.localStream);
        this.streamAttached = true;
        return true;
      } else {
        l('DEBUG') && console.log(this+'attachLocalStream() Stream already attached');
        return true;
      }
    } else {
      console.error('this.rtcommEndpoint.localStream is not set');
      return false;
    }
  },
  
  connect = function() {
    // We may not be init'd check first.
    if (this._sigSession === null) {
      l('DEBUG') && console.log(this+'.connect() -- Initializing on Connection');
      this.init();
    }
    
    // If we have a _peerConnection from init() we need to attach stream
    // TODO:  Attach a FAKE stream possibly...
    if (this._peerConnection) {
      if(!this.attachLocalStream()) {
        throw new Error('Unable to attach localStream');
      }
    }
    
    // What is our state?
    var state = this.getState();
    l('DEBUG') && console.log("STATE in connect..."+state);
    switch(state)
    {
    case "RINGING":
      if (this._peerConnection) {
        l('DEBUG') && console.log('connect() calling createAnswer');
        this._peerConnection.createAnswer(this._gotAnswer.bind(this), function(error){
          console.error('failed to create answer', error);
        });
      } else {
        console.log("If there's no PEER CONNECTION, we still need to setup the SigSession.");
        this._sigSession.respond();
      }
     break;
    case "CONNECTED":
      /* If connect() is called while CONNECTED, we RENEGOTIATE */
      if (this._peerConnection){
        this._peerConnection.createOffer(
        /*success*/  function(offer) {
          l('DEBUG') && console.log(this+'.connect RENEGOTIATING', offer);
          this._peerConnection.setLocalDescription(offer,function() {
              this.send(offer);
              console.log('calling updateIce()');
              this._peerConnection.updateIce();
          }.bind(this), function(error){
              console.error(error);
          });
        }.bind(this),
        /*failed*/ function(error) {
          console.log('Failed to create offer for Renegotiate', error);
        });
      } else {
       l('DEBUG') && console.log("No Peerconnection, nothing to do.");
      }
      break;
    case "DISCONNECTED":
      this._setState("TRYING");
   
      // Create Offer and send it.
      if (this._peerConnection) {
        l('DEBUG') && console.log(this+'.connect - creating Offer', this._peerConnection);
        this._peerConnection.createOffer(
          function(offer){
              l('DEBUG') && console.log(this+'.connect - created Offer: ', offer);
              this._peerConnection.setLocalDescription(offer,function() {
                l('DEBUG') && console.log('connect - setLocalDescription Success');
                }, function(error){
                  console.error(error);
                });
            this._sigSession.start({toEndpointID:this.toEndpointID, sdp: offer});
        }.bind(this),
        function(error) {
          console.log('Failed to create offer', error);
        });
      } else {
        l('DEBUG') && console.log(this+'.connect - beginning session');
        this._sigSession.start({toEndpointID:this.toEndpointID, content: null});
      }
      break;
    default:
      console.error('Unknown State in connect(): ' + state);
    }
  
  },


  /* internally used */
  
  send = function(msg) {
    /*
     * 
     * we send messages that are:
     *   {type: [offer|answer|icecandidate|user], [sdp|candidate|userdata]: ... }
     */
    msg = (msg && msg.type) ? msg : {'type':'user', 'userdata': {'message': msg}};
    // If there is a _sigSession, the message should be sent over it.  If there isn't, we will put the content inside a lower level message.
    if (this._sigSession) {
      this._sigSession.send(msg);
    }
  },
  
  destroy = function() {
    l('DEBUG') && console.log(this+'.destroy() Destroying the Connection');
    if (this._sigSession && this._sigSession.getState() !== 'stopped') {
      this._sigSession.stop();
      this._sigSession = null;
    } else {
      // already stopped, close it.
      this._sigSession = null;
    }
    if (this._peerConnection) {
      this._peerConnection.close();
      this._peerConnection = null;
    }
    if (this.getState() !== 'DISCONNECTED') {
      this._setState('DISCONNECTED');
    }
  },

  //TODO Not done, we should DESTROY ourselves too... how?
  // Do we need a Destroy Connection at the higher level to clean us up? 
  
  disconnect = function() {
    this.destroy();
  },

  update = function() {
    // Send another OFFER (presumably w/ a new SDP)
  },

  getState = function() {
    return this.state;
  },
  _setState = function(state) {
    if (state in this.STATES ) {
      this.state = state;
      this._emit(state.toLowerCase());
    }
  },

  /* We expect a single 'string' of an event typically */

  _emit = function(event, name) {
        var emitEvent = {};
      var userid = name?name:this.toEndpointID;
      l('TRACE') && console.log('WebRTCConnection._emit - TRACE: emitting event for id: '+userid);
      if (event in this.EVENTS) {
        emitEvent.name =  event;
        if (typeof userid !== 'undefined') {
          emitEvent.message = this.EVENTS[event].replace(/\%s/, userid);
        } else {
          emitEvent.message = this.EVENTS[event].replace(/\%s/, "unknown");
        }
        emitEvent.object = this.getStatus();
      } else if (event.name && event.message ) {
        emitEvent = event;
      } else {
        // Assume its a MEssage, emit a MESSAGE event w/ the name
        emitEvent.name = 'message';
        emitEvent.message = event;
        emitEvent.object = this.getStatus();
      }
      // Emit an event.
      if (this.onEvent && typeof this.onEvent === 'function') {
        l('DEBUG') && console.log(this+'._emit emitting event: ', emitEvent);
        this.onEvent(emitEvent);
      } else {
        l('DEBUG') && console.log(this+'_emit Nothing to do w/: ',event);
      } 
  },
  sendData = function() {
  },
  /** return the status of the connection */
  getStatus = function() {
    var connStatus = {};
    connStatus.state = this.state;
    connStatus.session = null;
    connStatus.pc = null;
    connStatus.pcSigState = null;
    connStatus.pcIceGatheringState = null;
    connStatus.pcIceConnectionState = null;
    if (this._sigSession) {
      connStatus.session = this._sigSession.id;
    }
    if (this._peerConnection) {
      connStatus.pc = this._peerConnection;
      connStatus.pcSigState = this._peerConnection.signalingState;
      connStatus.pcIceGatheringState = this._peerConnection.iceGatheringState;
      connStatus.pcIceConnectionState = this._peerConnection.iceConnectionState;
    }
    connStatus.remoteID = this.toEndpointID;
    connStatus.thisID = this.endpointConnection.userid;
    return connStatus;
  },
  getName = function() {
    return this.name || this.constructor.name;
  },
  
 
  toString = function() {
    return "WebRtcConnection[" + this.id +"]";
  };

  return {
    init: init,
    connect: connect,
    disconnect: disconnect,
    update: update,
    attachLocalStream: attachLocalStream,
    _processMessage: _processMessage,
    getState: getState,
    _setState: _setState,
    _gotAnswer: _gotAnswer,
    _emit:_emit,
    getStatus: getStatus,
    destroy: destroy,
    send: send,
    sendData: sendData,
    getName: getName,
    toString: toString
  };

}();  // End of Prototype


function createSignalingSession(context) {
  
  l('DEBUG') && console.log("createSignalingSession context: ", context);
  /* global SigSession : false */
  var sessid = null;
  var toTopic = null;
  if (context._referralSession) {
    var details = context._referralSession.referralDetails;
    sessid =  (details && details.sessionID) ? details.sessionID : null;
    context.toEndpointID =  (details && details.toEndpointID) ? details.toEndpointID : null;
    toTopic =  (details && details.toTopic) ? details.toTopic : null;
  }
 
  if (!context.toEndpointID) {
    throw new Error('toEndpointID must be set in WebRTCConnection object');
  }
  
  var session = context.endpointConnection.createSession({
    id : sessid,
    toTopic : toTopic,
    toEndpointID: context.toEndpointID,
    appContext: context.appContext
    
    });

  return session;
}
function addSessionCallbacks(context, session) {
   // Define our callbacks for the session.
 
  session.on('pranswer', function(content){
    context._processMessage(content);
  });
  session.on('ice_candidate', function(content){
    context._processMessage(content);
  });
  session.on('message', function(content){
    l('DEBUG') && console.log('SigSession callback called to process content: ', content);
    context._processMessage(content);
  });
  
  session.on('started', function(content){
    // Our Session is started!
    if (content) { context._processMessage(content);}
    //TODO:  This may have some state conflict...
    context.ready = true;
    if (context.pc) {
      if (context.pc.signalingState === 'stable') {
        context._setState("CONNECTED");
      } else if (context.pc.signalingState === 'closed'){
        // There was on offer created, we are just 'READY'
        context._setState('READY');
      } else {
        // All other states of the pc mean we are in the middle of a call
        context._setState("RINGING");
      }
    } else {
      context._setState('STARTED');
    }
    
    if (context._referralSession) {
      context._referralSession.respond(true);
    }
  });
  
  session.on('stopped', function() {
    console.log('stopped , cleaning up...');
    // we need to do some destruction
    context.destroy();
  });
  
  session.on('starting', function() {
    
  });
  session.on('failed', function(message) {
    context._setState('FAILED');
    context.destroy();
  });
  
  l('DEBUG') && console.log('createSignalingSession created!', session);
  
 // session.listEvents();
  return true;
}

function createPeerConnection(/* object */ context) {
  
  var configuration = context.iceServers || null; 
  // Must be true for Firefox
  var pcConstraints = {'optional': [{'DtlsSrtpKeyAgreement': 'true'}]};
  // var pcConstraints =  null;
  /* global RTCPeerConnection: false */
  var peerConnection = null;
  
 
  if (typeof MyRTCPeerConnection !== 'undefined'){
    l('DEBUG')&& console.log("Creating PeerConnection with configuration: " + configuration + "and contrainsts: "+ pcConstraints);
    peerConnection = new MyRTCPeerConnection(configuration, pcConstraints);
   
    peerConnection.onicecandidate = function (evt) {
      
      l('DEBUG') && console.log(this+'onicecandidate Event',evt);
      // If we don't want to 'Trickle' the events, we need to wait here...
      // When we get a Null event, then Send the Offer/Answer...
      // We have changed this content... so, we have to 
      // have a candidate and trickle is on.
      if (evt.candidate) {
          l('DEBUG') && console.log(this+'onicecandidate Sending Ice Candidate');
          var msg = {'type': evt.type,'candidate': evt.candidate};
          this.send(msg);
          
      }
    }.bind(context);  // End of onicecandidate

    peerConnection.oniceconnectionstatechange = function (evt) {
      if (this._peerConnection === null) {
        // If we are null, do nothing... Weird cases where we get here I don't understand yet.
        return;
      }
      l('DEBUG') && console.log(this+' oniceconnectionstatechange ICE STATE CHANGE '+ this._peerConnection.iceConnectionState);
    }.bind(context);  // End of oniceconnectionstatechange

    // once remote stream arrives, show it in the remote video element
    peerConnection.onaddstream = function (evt) {
       console.log('Called??');
      //Only called when there is a VIDEO or AUDIO stream on the remote end...
      l('DEBUG') && console.log(this+' onaddstream Remote Stream Arrived!', evt);
      l('DEBUG') && console.log("TRACE onaddstream AUDIO", evt.stream.getAudioTracks());
      l('DEBUG') && console.log("TRACE onaddstream Video", evt.stream.getVideoTracks());

      if (evt.stream.getAudioTracks().length > 0) {
        this.audio = true;
      }
      if (evt.stream.getVideoTracks().length > 0) {
        this.video = true;
      }
      /*
       * At this point, we now know what streams are requested 
       * we should see what component we have (if we do) and see which one
       * we find and confirm they are the same... 
       * 
       */
     
      var rtcommEndpoint = this.rtcommEndpoint;
      if (this._peerConnection && this.rtcommEndpoint) {
        /* global URL: true */
        this.rtcommEndpoint.setInboundMediaStream(evt.stream);
        l('DEBUG') && console.log('peerConnection.onaddstream - Attached stream to rtcommEndpoint: ', this.rtcommEndpoint);
        /*  Commenting out -- Don't think we need to do this.
         * if(this.rtcommEndpoint.localStream){
          console.log("onaddstream  --> Adding LocalStream to FOUND rtcommEndpoint");
          this._peerConnection.addStream(this.rtcommEndpoint.localStream);
        }*/
      } else {
        // No UI Component... Need to Disconnect...
        console.error("peerConnection.onaddstream - Something is wrong, no peerConnection or rtcommEndpoint");
      }
    }.bind(context);
    
    peerConnection.onnegotiationneeded = function(evt) {
      l('DEBUG') && console.log('ONNEGOTIATIONNEEDED : Received Event - ', evt);
      if ( this._peerConnection.signalingState === 'stable' && this.getState() === 'CONNECTED') {
        // Only if we are stable, renegotiate!
        this._peerConnection.createOffer(
            /*onSuccess*/ function(offer){
              console.log(this+'connect Created Offer ', offer);
                
              this._peerConnection.setLocalDescription(offer,
                  /*onSuccess*/ function() {
                  this.send(offer);
              }.bind(this), 
                  /*onFailure*/ function(error){
                    console.error(error);
                  });
             
                
            }.bind(this),
            /*onFailure*/ function(error) {
              console.error(error);
            });
      } else {
        l('DEBUG') && console.log('ONNEGOTIATIONNEEDED Skipping renegotiate - not stable. State: '+ this._peerConnection.signalingState);
      }
    }.bind(context);
    peerConnection.onremovestream = function (evt) {
      // Stream Removed...
      if (this._peerConnection === null) {
        // If we are null, do nothing... Weird cases where we get here I don't understand yet.
        return;
      }
      // TODO: Emit an event...
      // cleanup(?)
    }.bind(context);

  } else {
    throw new Error("No RTCPeerConnection Available - unsupported browser");

  }
  return peerConnection;
}  // end of createPeerConnection
/*
 *  Following are used to handle different browser implementations of WebRTC
 */
var getBrowser = function() {
    if (navigator && navigator.mozGetUserMedia) {
      // firefox
      return("firefox", parseInt(navigator.userAgent.match(/Firefox\/([0-9]+)\./)[1], 10));
    } else if (navigator && navigator.webkitGetUserMedia) {
     return("chrome", parseInt(navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./)[2], 10));
    } else {
      return("Unknown","Unknown");
    } 
  };

  var MyRTCPeerConnection = (function() { 
    /*global mozRTCPeerConnection:false */
    /*global webkitRTCPeerConnection:false */
    if (navigator && navigator.mozGetUserMedia) {
      return mozRTCPeerConnection;
    } else if (navigator && navigator.webkitGetUserMedia) {
      return webkitRTCPeerConnection;
    } else {
      return null;
    //  throw new Error("Unsupported Browser: ", getBrowser());
    }
  })();
  
  var MyRTCSessionDescription = (function() { 
    /*global mozRTCSessionDescription:false */
    if (navigator && navigator.mozGetUserMedia) {
      return mozRTCSessionDescription;
    } else if (typeof RTCSessionDescription !== 'undefined' ) {
      return RTCSessionDescription;
    } else {
    	return null;
    //  throw new Error("Unsupported Browser: ", getBrowser());
    }
  })();
 
  l('DEBUG') && console.log("Setting RTCSessionDescription", MyRTCSessionDescription);

  var MyRTCIceCandidate = (function() { 
    /*global mozRTCIceCandidate:false */
    /*global RTCIceCandidate:false */
    
    if (navigator && navigator.mozGetUserMedia) {
      return mozRTCIceCandidate;
    } else if (typeof RTCIceCandidate !== 'undefined') {
      return RTCIceCandidate;
    } else {
      return null;
    //  throw new Error("Unsupported Browser: ", getBrowser());
    }
  })();
  l('DEBUG') && console.log("RTCIceCandidate", MyRTCIceCandidate);
  
 
  return WebRTCConnection;
}());



return { RtcommEndpointProvider: EndpointProvider };


}));


